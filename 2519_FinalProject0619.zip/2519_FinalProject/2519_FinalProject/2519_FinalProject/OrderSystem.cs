﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace _2519_FinalProject
{
    public partial class OrderSystem : Form
    {
        static int price = 0;
        int a, b;
        public OrderSystem()
        {
            InitializeComponent();
            this.ControlBox = false;
        }

        #region dataGridView2
        private void dataGridView2_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
        #endregion

        #region btnExit
        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Hide();
        }
        #endregion

        #region formLoad()
        private void formLoad()
        {
            SqlConnectionStringBuilder sqlConnStrBuilder = new SqlConnectionStringBuilder("server=usingnamespace.ddns.net;database=ordering;uid=wei;pwd=1212");
            ////sqlConnStrBuilder.DataSource = ".\\SQLEXPRESS";
            //sqlConnStrBuilder.DataSource = "usingnamespace.ddns.net";
            //sqlConnStrBuilder.UserID = "wei";
            //sqlConnStrBuilder.Password = "1212";
            //sqlConnStrBuilder.InitialCatalog = "ordering";
            //sqlConnStrBuilder.IntegratedSecurity = true;
            SqlConnection sqlConn = new SqlConnection(sqlConnStrBuilder.ConnectionString);
            sqlConn.Open();
            for (int i = 0; i < orderingDataSet.Tables.Count; i++)
            {
                if (orderingDataSet.Tables[i].ToString() == "employee") { continue; }
                cbxMenu.Items.Add(orderingDataSet.Tables[i].ToString());
            }
            sqlConn.Close();
        }
        #endregion

        #region check_items
        private void checkitems(string state)
        {
            if (state == "soup")
            { groupBox1.Visible = false; groupBox2.Visible = false; cbxCheese.Visible = false; cbxLarge.Visible = false; }
            else if (state == "rice")
            { groupBox1.Visible = false; groupBox2.Visible = false; cbxCheese.Visible = true; cbxLarge.Visible = true; }
            else if (state == "broil")
            { groupBox1.Visible = false; groupBox2.Visible = true; }
            else
            { groupBox1.Visible = true; groupBox2.Visible = false; cbxCheese.Visible = true; cbxLarge.Visible = true; }
        }
        #endregion 

        #region connect to DB
        private void accessDB(string element)
        {
            SqlConnectionStringBuilder sqlConnStrBuilder = new SqlConnectionStringBuilder("server=usingnamespace.ddns.net;database=ordering;uid=wei;pwd=1212");
            ////sqlConnStrBuilder.DataSource = ".\\SQLEXPRESS";
            //sqlConnStrBuilder.DataSource = "USINGNAMESPACE";
            //sqlConnStrBuilder.InitialCatalog = "ordering";
            //sqlConnStrBuilder.IntegratedSecurity = true;
            SqlConnection sqlConn = new SqlConnection(sqlConnStrBuilder.ConnectionString);
            sqlConn.Open();
            SqlDataAdapter sqlda = new SqlDataAdapter("SELECT * FROM " + element, sqlConn);
            DataSet ds = new DataSet("ds_" + element);
            sqlda.Fill(ds, "ds_" + element);
            bindingSource1.DataSource = ds.Tables[0];
            bindingNavigator1.BindingSource = bindingSource1;
            dataGridView1.DataSource = bindingSource1;
            dataGridView1.AutoResizeRows();
            dataGridView1.AutoResizeColumns();
            bindingNavigator1.BindingSource = bindingSource1;
            sqlConn.Close();
        }
        #endregion

        #region cbxMenu_SelectedIndexChanged
        private void cbxMenu_SelectedIndexChanged_1(object sender, EventArgs e)
        {
            cancel();
            if (cbxMenu.SelectedIndex == 0) { checkitems("broil"); accessDB("broil"); }
            else if (cbxMenu.SelectedIndex == 1) { checkitems("noodles"); accessDB("noodles"); }
            else if (cbxMenu.SelectedIndex == 2) { checkitems("pasta"); accessDB("pasta"); }
            else if (cbxMenu.SelectedIndex == 3) { checkitems("rice"); accessDB("rice"); }
            else if (cbxMenu.SelectedIndex == 4) { checkitems("soup"); accessDB("soup"); }
        }
        #endregion

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (dataGridView1.Rows[e.RowIndex].Cells[0].Value == null) return;
            txbItems.Text = dataGridView1.Rows[e.RowIndex].Cells[0].Value.ToString();
            txbPrice.Text = dataGridView1.Rows[e.RowIndex].Cells[1].Value.ToString();
        }

        #region formLoad
        private void OrderSystem_Load(object sender, EventArgs e)
        {
            // TODO: 這行程式碼會將資料載入 'orderingDataSet1.employee' 資料表。您可以視需要進行移動或移除。
            //this.employeeTableAdapter.Fill(this.orderingDataSet1.employee);
            // TODO: 這行程式碼會將資料載入 'orderingDataSet.broil' 資料表。您可以視需要進行移動或移除。
            //this.broilTableAdapter.Fill(this.orderingDataSet.broil);
            formLoad();
        }
        #endregion

        private void dataGridView1_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            
        }

        #region btnAdd()
        private void btnAdd_Click(object sender, EventArgs e)
        {
            try
            {
                string RiceNoodles = "";
                string NoodlesItem = "";
                if (rdbNoodles.Checked) RiceNoodles = "麵";
                else if (rdbRice.Checked) RiceNoodles = "飯";
                if (rdbSquid.Checked) NoodlesItem = "墨魚麵";
                else if (rdbPenne.Checked) NoodlesItem = "斜管麵";
                if(groupBox2.Visible)
                {
                    if (rdbNoodles.Checked == false && rdbRice.Checked == false)
                    {
                        MessageBox.Show("請選擇飯或麵類", "Error!", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        return;
                    }
                }
                dataGridView2.Rows.Add(new Object[] { txbItems.Text,cbxLarge.CheckState,cbxCheese.CheckState,
                RiceNoodles,NoodlesItem,txbPrice.Text,numericUpDown1.Value.ToString(),
                calc(txbPrice.Text,numericUpDown1.Value.ToString()).ToString()});
                Total();
                cancel();
            }
            catch (Exception ee) { MessageBox.Show(ee.ToString(),"Error!",
                MessageBoxButtons.OK,MessageBoxIcon.Error); }
        }
        #endregion

        private void Total()
        {
            int total = 0;
            for(int i=0;i<dataGridView2.Rows.Count;i++)
            {
                DataGridViewRow row = dataGridView2.Rows[i];
                if (row.Cells[0].Value != null)
                    total += int.Parse(row.Cells[7].Value.ToString());
            }
            tbxTotal.Text = total.ToString();
        }

        #region calc
        private int calc(string price,string quantity)
        {
            int qq = int.Parse(price) * int.Parse(quantity);
            return qq;
        }
        #endregion 

        #region cbxCheese_CheckedChanged
        private void cbxCheese_CheckedChanged(object sender, EventArgs e)
        {
            if (txbPrice.Text == "") { return; }
            a = int.Parse(txbPrice.Text);
            if (cbxCheese.Checked)
            { txbPrice.Text = (a + 10).ToString(); }
            else { txbPrice.Text = (a - 10).ToString(); }
        }
        #endregion

        #region cbxLarge_CheckedChanged
        private void cbxLarge_CheckedChanged(object sender, EventArgs e)
        {
            if (txbPrice.Text == "") { return; }
            a = int.Parse(txbPrice.Text);
            if (cbxLarge.Checked)
            {txbPrice.Text = (a + 10).ToString();}
            else{ txbPrice.Text = (a - 10).ToString(); }
        }
        #endregion

        private void btnDelete_Click(object sender, EventArgs e){cancel();}

        private void rdbSquid_CheckedChanged(object sender, EventArgs e)
        {
            if (txbPrice.Text == "") { return; }
            a = int.Parse(txbPrice.Text);
            if (rdbSquid.Checked)
            { txbPrice.Text = (a + 20).ToString(); }
            else { txbPrice.Text = (a - 20).ToString(); }
        }

        private void rdbPenne_CheckedChanged(object sender, EventArgs e)
        {
            if (txbPrice.Text == "") { return; }
            a = int.Parse(txbPrice.Text);
            if (rdbPenne.Checked)
            { txbPrice.Text = (a + 10).ToString(); }
            else { txbPrice.Text = (a - 10).ToString(); }
        }

        private void dataGridView2_ColumnDisplayIndexChanged(object sender, DataGridViewColumnEventArgs e)
        {

        }

        private void dataGridView1_BindingContextChanged(object sender, EventArgs e)
        {
        }

        private void dataGridView2_RowContextMenuStripChanged(object sender, DataGridViewRowEventArgs e)
        {
        }

        private void dataGridView1_RowContextMenuStripChanged(object sender, DataGridViewRowEventArgs e)
        {
        }

        private void dataGridView1_SelectionChanged(object sender, EventArgs e)
        {
            cancel();
        }

        private void btnCheckout_Click(object sender, EventArgs e)
        {
            string strMsgInsert = "";
            Random RR = new Random();
            SqlConnection dataConnection = new SqlConnection();
            String sqlConnectionStr = "server=usingnamespace.ddns.net;database=ordering;uid=wei;pwd=1212";

            strMsgInsert = @"INSERT INTO order([OrderNum],[items],[large],[cheese],[RiceNoodles],
                [CuttlePenne],[price],[quantity],[total]) 
                VALUES(@value1,@value2,@value3,@value4,@value5,@value6,@value7,@value8,@value9)";
                
            SqlCommand mySqlCmd = new SqlCommand(strMsgInsert, dataConnection);
            try
            {
                dataConnection.ConnectionString = sqlConnectionStr;
                dataConnection.Open();
                for (int i = 0; i < dataGridView2.Rows.Count; i++)
                {
                    mySqlCmd.Parameters.AddWithValue("@value1", RR.Next(1111, 9999));
                    mySqlCmd.Parameters.AddWithValue("@value2", dataGridView2.Rows[i].Cells[0].Value.ToString());
                    mySqlCmd.Parameters.AddWithValue("@value3", dataGridView2.Rows[i].Cells[1].Value.ToString());
                    mySqlCmd.Parameters.AddWithValue("@value4", dataGridView2.Rows[i].Cells[2].Value.ToString());
                    mySqlCmd.Parameters.AddWithValue("@value5", dataGridView2.Rows[i].Cells[3].Value.ToString());
                    mySqlCmd.Parameters.AddWithValue("@value6", dataGridView2.Rows[i].Cells[4].Value.ToString());
                    mySqlCmd.Parameters.AddWithValue("@value7", dataGridView2.Rows[i].Cells[5].Value.ToString());
                    mySqlCmd.Parameters.AddWithValue("@value8", dataGridView2.Rows[i].Cells[6].Value.ToString());
                    mySqlCmd.Parameters.AddWithValue("@value9", dataGridView2.Rows[i].Cells[7].Value.ToString());
                }
                //執行SQL INSERT 語法
                mySqlCmd.ExecuteNonQuery();

                //關閉資料庫
                dataConnection.Close();
            }
            catch (Exception ee)
            {
                //抓錯誤訊息
                MessageBox.Show(ee.Message.ToString(), "警告", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            finally
            {
                //清除
                mySqlCmd.Cancel();
                dataConnection.Close();
                dataConnection.Dispose();
            }
        }

        #region cancel()
        private void cancel()
        {
            txbItems.Text = "";txbPrice.Text = "";numericUpDown1.Value = 1;
            cbxCheese.Checked = false;cbxLarge.Checked = false;
            rdbNoodles.Checked = false;rdbPenne.Checked = false;
            rdbRice.Checked = false;rdbSquid.Checked = false;
            txbPrice.Text = "";
        }
        #endregion
    }
}
