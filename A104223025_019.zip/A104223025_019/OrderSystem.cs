﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.OleDb;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _025019FinalProject
{
    public partial class OrderSystem : Form
    {
        public OrderSystem()
        {
            InitializeComponent();
        }
        string state = "";
        private void OrderSystem_Load(object sender, EventArgs e)
        {
            // TODO: 這行程式碼會將資料載入 'menu1DataSet.焗烤' 資料表。您可以視需要進行移動或移除。
            //this.焗烤TableAdapter.Fill(this.menu1DataSet.焗烤);
        }

        #region Order
        private void btnPasta_Click(object sender, EventArgs e)
        { checksoup("Pasta"); accessDB("義大利麵");}

        private void btnNoodles_Click(object sender, EventArgs e)
        { checksoup("Noodles"); accessDB("湯麵");}

        private void btnRice_Click(object sender, EventArgs e)
        {checksoup("rice");accessDB("飯");}

        private void btnBroil_Click(object sender, EventArgs e)
        {checksoup("Broil");accessDB("焗烤");}

        private void btnSoup_Click(object sender, EventArgs e)
        {checksoup("soup");accessDB("湯品");}
        #endregion

        #region connect to accessDB
        private void accessDB(string element)
        {
            //第一步：設定連線字串
            String strConnectionString = "Provider=Microsoft.Jet.OLEDB.4.0;Data Source=Menu1.mdb";

            //第二步：建立資料庫連線物件
            OleDbConnection cn = new OleDbConnection(strConnectionString);

            //第三步：開啟資料庫連線
            cn.Open();

            //取得資料並填入 DataSet
            OleDbDataAdapter oleda = new OleDbDataAdapter("SELECT * FROM " + element, cn);
            DataSet ds = new DataSet("ds_"+element);
            oleda.Fill(ds, "ds_"+element);
            int x = 100;
            //第六步：設定 DataSource
            //DataGridView1.DataSource = ds.Tables("ds_客戶")
            bindingSource1.DataSource = ds.Tables[0];
            dataGridView1.DataSource = bindingSource1;
            //dataGridView1.AutoResizeRows();
            dataGridView1.AutoResizeColumns();
            bindingNavigator1.BindingSource = bindingSource1;

            //關閉資料庫連線
            cn.Close();
        }
        #endregion

        #region 方法 checksoup
        private void checksoup(string state)
        {
            if (state == "soup")
            { groupBox1.Visible = false; groupBox2.Visible=false; cbxCheese.Visible = false; cbxLarge.Visible = false; }
            else if(state=="rice")
            {groupBox1.Visible = false; groupBox2.Visible = false; cbxCheese.Visible = true;cbxLarge.Visible = true; }
            else if(state=="Broil")
            { groupBox2.Visible = true; }
            else
            { groupBox1.Visible = true; groupBox2.Visible = false; cbxCheese.Visible = true; cbxLarge.Visible = true; }
        }
        #endregion

        #region Add
        private void btnAdd_Click(object sender, EventArgs e)
        {

        }
        #endregion

        #region Exit
        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }
        #endregion

        #region Checkout
        private void btnCheckout_Click(object sender, EventArgs e)
        {
            DialogResult myResult = MessageBox.Show("確定結帳?", "結帳", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (myResult == DialogResult.Yes)
            {

            }
        }
        #endregion

        private void btnLoad_Click(object sender, EventArgs e)
        {
            //第一步：設定連線字串
            String strConnectionString = "Provider=Microsoft.Jet.OLEDB.4.0;Data Source=Menu1.mdb";

            //第二步：建立資料庫連線物件
            OleDbConnection cn = new OleDbConnection(strConnectionString);

            //第三步：開啟資料庫連線
            cn.Open();

            //取得資料並填入 DataSet
            OleDbDataAdapter oleda = new OleDbDataAdapter("SELECT * FROM " + element, cn);
            DataSet ds = new DataSet("ds_" + element);
            oleda.Fill(ds, "ds_" + element);
            
            cn.Close();
        }
    }
}
