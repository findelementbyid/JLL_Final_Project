﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.OleDb;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _025019FinalProject
{
    public class check
    {
        static Form f1 = new OrderSystem();
        static Form f2 = new MenuManagement();
        static Form f3 = new salesFigure();
        public static void checkid(string page,string account,string passeword)
        {
            String strConnectionString = "Provider=Microsoft.Jet.OLEDB.4.0;Data Source=Menu1.mdb";
            OleDbConnection cn = new OleDbConnection(strConnectionString);
            OleDbDataReader datareader;
            cn.Open();

            string sql = "SELECT * FROM 員工資料 Where 員工編號='" + account + "'" + "and 員工密碼 = '" + passeword + "'";
            OleDbCommand cmd = new OleDbCommand(sql, cn);
            cmd.Connection = cn;
            datareader = cmd.ExecuteReader();
            if (page == "1")
            {
                if (datareader.Read())
                { f1.Show(); }
                else
                { MessageBox.Show("帳號或密碼不正確"); return; }
            }
            if (page == "2")
            {
                if (datareader.Read())
                {
                    if (account.Split('1')[0] == "A") { f2.Show(); }
                    else { MessageBox.Show("權限不足"); return; }
                }
            }
            if (page == "3") 
            {
                if (account.Split('1')[0] == "A") { f3.Show(); }
                else { MessageBox.Show("權限不足"); return; }
            }
            cn.Close();
        }
    }
}
