﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace _2519_FinalProject
{
    public partial class MainEntrance : Form
    {
        public MainEntrance()
        {
            InitializeComponent();
            this.ControlBox = false;
        }

        private void btnOrder_Click(object sender, EventArgs e)
        {
            check.checkid("1", txbAccount.Text, txbPassword.Text);
        }

        private void btnMenuM_Click(object sender, EventArgs e)
        {
            check.checkid("2", txbAccount.Text, txbPassword.Text);
        }

        private void btnAnalyze_Click(object sender, EventArgs e)
        {
            check.checkid("3", txbAccount.Text, txbPassword.Text);
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
