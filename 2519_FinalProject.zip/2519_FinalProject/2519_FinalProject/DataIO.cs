﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Data;
using _2519_FinalProject;

namespace _2519_FinalProject
{   public class check
    {
        static Form f0 = new MainEntrance();
        static Form f1 = new OrderSystem();
        static Form f2 = new MenuManagement();
        static Form f3 = new salesFigure();
        public static List<string> menu = new List<string>();

        #region Delete
        public static void Delete(string table, string txb1, string txb2)
        {
            String strSQL = "";
            try
            {
                DialogResult result = MessageBox.Show("確定刪除?", "注意!", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
                if (result == DialogResult.Yes)
                {
                    if (table == "employee")
                    { strSQL = " DELETE FROM " + table + " WHERE userID ='" + txb1 + "' and password ='" + txb2 + "'"; }
                    else
                    { strSQL = " DELETE FROM " + table + " WHERE items ='" + txb1 + "' and price ='" + txb2 + "'"; }
                    SqlConnection sqlConn = new System.Data.SqlClient.SqlConnection("server=usingnamespace.ddns.net;database=ordering;uid=wei;pwd=1212");
                    sqlConn.Open();
                    SqlCommand sqlcommand = new SqlCommand(strSQL, sqlConn);
                    sqlcommand.ExecuteNonQuery();
                    sqlConn.Close();
                    MessageBox.Show("已經成功刪除\n" + txb1 + "\t" + txb2, "刪除成功", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                else return;
            }
            catch (Exception ee) { MessageBox.Show(ee.Message); }
        }
        #endregion

        #region Insert
        public static void Insert(string table, string txb1, string txb2)
        {
            String strSQL = "";
            try
            {
                DialogResult result = MessageBox.Show("確定新增?", "注意!", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
                if (result == DialogResult.Yes)
                {
                    if (table == "employee")
                    { strSQL = " INSERT INTO " + table + " (userID,password) VALUES ('" + txb1 + "','" + txb2 + "')"; }
                    else
                    { strSQL = " INSERT INTO " + table + " (items,price) VALUES ('" + txb1 + "','" + txb2 + "')"; }
                    SqlConnection sqlConn = new System.Data.SqlClient.SqlConnection("server=usingnamespace.ddns.net;database=ordering;uid=wei;pwd=1212");
                    sqlConn.Open();
                    SqlCommand sqlcommand = new SqlCommand(strSQL, sqlConn);
                    sqlcommand.ExecuteNonQuery();
                    sqlConn.Close();
                    MessageBox.Show("已經成功新增\n" + txb1 + "\t" + txb2, "新增成功", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                else return;
            }
            catch (Exception ee) { MessageBox.Show(ee.Message); }
        }
        #endregion

        #region Update
        public static void Update(string table,string txb1,string txb2)
        {
            String strSQL = "";
            try
            {
                DialogResult result = MessageBox.Show("確定要修改?", "注意!", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
                if (result == DialogResult.Yes)
                {
                    if (table == "employee")
                    { strSQL = " UPDATE " + table + " SET password ='" + txb2 + "' WHERE userID ='" + txb1 + "'"; }
                    else
                    { strSQL = " UPDATE " + table + " SET price ='" + txb2 + "' WHERE items ='" + txb1 + "'"; }
                    SqlConnection sqlConn = new System.Data.SqlClient.SqlConnection("server=usingnamespace.ddns.net;database=ordering;uid=wei;pwd=1212");
                    sqlConn.Open();
                    SqlCommand sqlcommand = new SqlCommand(strSQL, sqlConn);
                    sqlcommand.ExecuteNonQuery();
                    sqlConn.Close();
                    MessageBox.Show("已經成功修改\n" + txb1 + "\t" + txb2, "修改成功", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                else return;
            }
            catch (Exception ee) { MessageBox.Show(ee.ToString()); }
        }
        #endregion

        #region login
        public static bool login(string page,string server,string user,string password)
        {
            try
            {
                SqlConnectionStringBuilder sqlConnStrBuilder =
                    new SqlConnectionStringBuilder("server=" + server + ";database=ordering;uid=" + user + ";pwd=" + password);
                SqlConnection sqlConn = new SqlConnection(sqlConnStrBuilder.ConnectionString);
                sqlConn.Open();
                f0.Show();
                return true;
            }
            catch(Exception ee) { MessageBox.Show(ee.ToString());return false; }
        }

        #endregion

        #region check ID
        public static void checkid(string page, string account, string passeword)
        {
            SqlConnectionStringBuilder sqlConnStrBuilder = 
                new SqlConnectionStringBuilder("server=usingnamespace.ddns.net;database=ordering;uid=wei;pwd=1212");
            ////sqlConnStrBuilder.DataSource = ".\\SQLEXPRESS";sqlConnStrBuilder.DataSource = "USINGNAMESPACE";
            //sqlConnStrBuilder.InitialCatalog = "ordering";
            //sqlConnStrBuilder.IntegratedSecurity = true;
            SqlConnection sqlConn = new SqlConnection(sqlConnStrBuilder.ConnectionString);
            sqlConn.Open();
            SqlDataReader datareader;
            string sql = "SELECT * FROM employee Where userID='" + account + "'" + "and password = '" + passeword + "'";
            SqlCommand cmd = new SqlCommand(sql, sqlConn);
            cmd.Connection = sqlConn;
            datareader = cmd.ExecuteReader();
            if (page == "1")
            {
                if (datareader.Read())
                { f1.Show(); }
                else
                { MessageBox.Show("帳號或密碼不正確", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error); return; }
            }
            if (page == "2")
            {
                if (datareader.Read())
                {
                    if (account.Split('1')[0] == "A") { f2.Show(); }
                    else { MessageBox.Show("權限不足", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error); return; }
                }
                else
                { MessageBox.Show("帳號或密碼不正確", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error); return; }
            }
            if (page == "3")
            {
                if (datareader.Read())
                {
                    if (account.Split('1')[0] == "A") { f3.Show(); }
                    else { MessageBox.Show("權限不足", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error); return; }
                }
                else
                { MessageBox.Show("帳號或密碼不正確", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error); return; }
            }
            sqlConn.Close();
        }
        #endregion
    }
}
