﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using ZedGraph;

namespace _2519_FinalProject
{
    public partial class salesFigure : Form
    {
        public salesFigure()
        {
            InitializeComponent();
        }

        #region 連接資料庫
        private void salesFigure_Load(object sender, EventArgs e)
        {
            // TODO: 這行程式碼會將資料載入 'orderingDataSet4.transaction' 資料表。您可以視需要進行移動或移除。
            this.transactionTableAdapter.Fill(this.orderingDataSet4.transaction);
        }
        #endregion

        #region 圖表------------>

        #region 折線圖
        public void createGraphLine(ZedGraphControl zgc, String category, String quantity, String title)
        {
            GraphPane myPane = zgc.GraphPane;

            myPane.Title.Text = title;
            myPane.XAxis.Title.Text = category;

            List<PointPairList> list = new List<PointPairList>();
            List<LineItem> myCurve = new List<LineItem>();
            List<int> num = new List<int>();
            List<string> name = new List<string>();
            int x;
            for (int i = 0; i < dataGridView2.RowCount; i++)
            {
                x = i;
                name.Add(dataGridView2.Rows[i].Cells[0].Value.ToString());
                num.Add(int.Parse(dataGridView2.Rows[i].Cells[1].Value.ToString()));
            }
            //for (int i = 0; i < 5; i++)
            //{
            //    //x = (double)i + 5;
            //    //y1 = 1.5 + Math.Sin((double)i * 0.2);
            //    //y2 = 3.0 * (1.5 + Math.Sin((double)i * 0.2));
            //    //z = 3.5 + Math.Cos((double)i * 0.8);
            //    x = (double)i;
            //    y1 = rand.NextDouble() * 100;
            //    y2 = rand.NextDouble() * 100;
            //    z = rand.NextDouble() * 100;

            //    list1.Add(x, y1);
            //    list2.Add(x, y2);
            //    list3.Add(x, z);
            //}
            //LineItem myCurve = myPane.AddCurve("Porsche", list1, Color.Red, SymbolType.Diamond);
            //LineItem myCurve2 = myPane.AddCurve("Piper", list2, Color.Blue, SymbolType.Circle);
            //LineItem myCurve3 = myPane.AddCurve("BMW", list3, Color.Green, SymbolType.Square);
            //zgc.AxisChange();
            //zgc.Refresh();
        }
        #endregion

        #region 圓餅
        public void createChart(ZedGraphControl zgc, String category, String quantity, String title)
        {
            zgc.GraphPane.CurveList.Clear();
            GraphPane myPane = zgc.GraphPane;

            myPane.Title.Text = title;
            myPane.Title.FontSpec.Size = 24f;
            myPane.Title.FontSpec.Family = "標楷體";

            myPane.Fill = new Fill(Color.White, Color.Goldenrod, 45.0f);
            myPane.Chart.Fill.Type = FillType.None;
            myPane.Legend.Position = LegendPos.Float;
            myPane.Legend.Location = new Location(0f, 0f, CoordType.PaneFraction, AlignH.Left, AlignV.Top);
            myPane.Legend.FontSpec.Size = 15f;
            myPane.Legend.IsHStack = false;

            Random rand = new Random();

            //暫時寫死資料
            //double[] chartCost = { 20.0, 5.0, 20.0, 15.0, 15.0, 25.0 };
            double[] chartCost = { rand.NextDouble(), rand.NextDouble(), rand.NextDouble(), rand.NextDouble(), rand.NextDouble(), rand.NextDouble() };
            string[] chartLabel = { "A", "B", "C", "D", "E", "F" };
            PieItem[] pp = myPane.AddPieSlices(chartCost, chartLabel);

            for (int i = 0; i < pp.Length; i++)
            {
                pp[i].LabelType = PieLabelType.Name_Value_Percent;
                pp[i].LabelDetail.FontSpec.Size = 15f;
            }
            zgc.AxisChange();
            zgc.Refresh();
        }
        #endregion

        #region 長條
        public void createBar(ZedGraphControl zgc, String category, String quantity, String title)
        {
            GraphPane myPane = zgc.GraphPane;

            myPane.Title.Text = title;
            myPane.XAxis.Title.Text = category;
            myPane.YAxis.Title.Text = quantity;

            PointPairList list = new PointPairList();
            PointPairList list2 = new PointPairList();
            PointPairList list3 = new PointPairList();
            Random rand = new Random();

            for (int i = 0; i < 5; i++)
            {
                double x = (double)i;
                double y = rand.NextDouble() * 1000;
                double y2 = rand.NextDouble() * 1000;
                double y3 = rand.NextDouble() * 1000;
                list.Add(x, y);
                list2.Add(x, y2);
                list3.Add(x, y3);
            }

            BarItem myCurve = myPane.AddBar("Porsche", list, Color.Blue);
            BarItem myCurve2 = myPane.AddBar("Piper", list2, Color.Red);
            BarItem myCurve3 = myPane.AddBar("BMW", list3, Color.Green);

            myPane.Chart.Fill = new Fill(Color.White,
            Color.FromArgb(255, 255, 166), 45.0F);
            BarItem.CreateBarLabels(myPane, false, "f0");

            zgc.AxisChange();
            zgc.Refresh();
        }
        #endregion

        #endregion

        #region 離開
        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Hide();
        }
        #endregion

        #region 確認品名
        private void btnConfirmItems_Click(object sender, EventArgs e)
        {
            dataGridView2.Rows.Clear();
            finfItemByCategory();
        }
        #endregion

        #region 折線圖顯示
        private void btnLineChart_Click(object sender, EventArgs e)
        {
            ZGC.GraphPane.CurveList.Clear();
            ZGC.GraphPane.GraphObjList.Clear();
            GraphPane myPane = ZGC.GraphPane;
            string category = txtBxCategory.Text;
            //createGraphLine(ZGC, "種類" + category, "數量", "分析圖表---折線圖");
        }
        #endregion

        #region 長條圖顯示
        private void btnBarChart_Click(object sender, EventArgs e)
        {
            ZGC.GraphPane.CurveList.Clear();
            ZGC.GraphPane.GraphObjList.Clear();
            GraphPane myPane = ZGC.GraphPane;
            string category = txtBxCategory.Text;
            createBar(ZGC, "種類" + category, "數量", "分析圖表---長條圖");
        }
        #endregion

        #region 圓餅圖顯示
        private void btnPieChart_Click(object sender, EventArgs e)
        {
            ZGCPie.GraphPane.CurveList.Clear();
            ZGCPie.GraphPane.GraphObjList.Clear();
            GraphPane myPane = ZGCPie.GraphPane;
            string category = txtBxCategory.Text;
            createChart(ZGCPie, "種類" + category, "數量", "分析圖表---圓餅圖");
        }
        #endregion

        #region 點擊選取
        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            try { txtBxCategory.Text = dataGridView1.Rows[e.RowIndex].Cells[2].Value.ToString(); }
            catch (Exception ex) { MessageBox.Show(ex.Message); }
        }
        #endregion

        #region 透過種類輸出品項
        private void finfItemByCategory()
        {
            try
            {
                int counter = 0;
                for (int i = 0; i < dataGridView1.RowCount - 1; i++)
                {
                    if (dataGridView1.Rows[i].Cells[2].Value.ToString() == txtBxCategory.Text)
                    {
                        //MessageBox.Show(dataGridView1.Rows[i].Cells[3].Value.ToString());
                        dataGridView2.Rows.Add(dataGridView1.Rows[i].Cells[3].Value.ToString(), dataGridView1.Rows[i].Cells[9].Value.ToString());
                        counter++;
                    }
                    else { /*MessageBox.Show("此訂單的種類" + txtBxCategory.Text + "只有" + counter + "個品項喔!");*/  }
                }
            }
            catch (Exception ex) { MessageBox.Show(ex.Message); }
        }
        #endregion
    }
}
