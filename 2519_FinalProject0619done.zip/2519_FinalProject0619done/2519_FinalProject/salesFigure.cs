﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using ZedGraph;
using System.Threading;
using System.Collections;

namespace _2519_FinalProject
{
    public partial class salesFigure : Form
    {
        public salesFigure()
        {
            InitializeComponent();
        }

        #region 宣告
        //List<PieItem> pieCurve = new List<PieItem>();
        //List<LineItem> lineCurve = new List<LineItem>();
        //List<BarItem> barCurve = new List<BarItem>();
        //List<PointPairList> AAA = new List<PointPairList>();
        BindingSource bindingSource = new BindingSource();
        Random random = new Random();
        PointPairList list = new PointPairList();
        List<string> Curve = new List<string>();
        List<string> Xdata = new List<string>();
        List<double> Ydata = new List<double>();
        int counter;
        #endregion

        #region 連接資料庫
        private void salesFigure_Load(object sender, EventArgs e)
        {
            // TODO: 這行程式碼會將資料載入 'orderingDataSet7.transaction1' 資料表。您可以視需要進行移動或移除。
            this.transaction1TableAdapter.Fill(this.orderingDataSet7.transaction1);
        }
        #endregion

        #region 圖表------------>

        #region 折線圖
        public void createLine(ZedGraphControl zgc, String category, String quantity, String title, DataGridView dataGridView)
        {
            Xdata.Clear(); Ydata.Clear();
            GraphPane myPane = zgc.GraphPane;
            counter = dataGridView.RowCount - 1;
            string temp;

            for (int i = 0; i < counter; i++)
            {
                temp = dataGridView.Rows[i].Cells[0].Value.ToString();
                if (Xdata.Contains(temp)) { Ydata[Xdata.IndexOf(temp)] += Double.Parse(dataGridView.Rows[i].Cells[10].Value.ToString()); }
                else
                {
                    Xdata.Add(temp);
                    Ydata.Add(Double.Parse(dataGridView.Rows[i].Cells[10].Value.ToString()));
                }
            }
            string[] x = new string[Xdata.Count];
            double[] y = new double[Ydata.Count];

            for (int i = 0; i < x.Length; i++)
            {
                x[i] = Xdata[i];
                y[i] = Ydata[i];
            }

            #region 畫圖美觀部分
            myPane.Chart.Fill.Type = FillType.None;
            myPane.Fill = new Fill(Color.White, Color.FromArgb(255, 255, 200), 90F);

            myPane.XAxis.Scale.TextLabels = x;
            myPane.XAxis.Type = AxisType.Text;
            myPane.XAxis.Title.Text = category;
            myPane.XAxis.Title.FontSpec.Size = 20f;
            myPane.XAxis.Title.FontSpec.Family = "微軟正黑體";

            myPane.Title.Text = title;
            myPane.Title.FontSpec.Size = 24f;
            myPane.Title.FontSpec.Family = "微軟正黑體";

            myPane.YAxis.Title.Text = quantity;
            myPane.YAxis.Title.FontSpec.Size = 20f;
            myPane.YAxis.Title.FontSpec.Family = "微軟正黑體";
            #endregion

            LineItem lineChart = myPane.AddCurve("銷售額", null, y, Color.FromArgb(random.Next(0, 255), random.Next(0, 255), random.Next(0, 255)));
            lineChart.Line.Fill = new Fill(Color.FromArgb(random.Next(0, 255), random.Next(0, 255), random.Next(0, 255)),
                Color.FromArgb(random.Next(0, 255), random.Next(0, 255), random.Next(0, 255)),
                Color.FromArgb(random.Next(0, 255), random.Next(0, 255), random.Next(0, 255)));

            zgc.Refresh();
            zgc.AxisChange();
            Curve.Clear();
        }
        #endregion

        #region 圓餅
        public void createChart(ZedGraphControl zgc, String title, DataGridView dataGridView)
        {
            #region 方法1 --> 沒有篩選重複值  不用!!! 
            /*
            zgc.GraphPane.CurveList.Clear();
            GraphPane myPane = zgc.GraphPane;
            counter = dataGridView2.RowCount - 1;

            myPane.Title.Text = title;
            myPane.Title.FontSpec.Size = 24f;
            myPane.Title.FontSpec.Family = "微軟正黑體";

            myPane.Fill = new Fill(Color.White, Color.Goldenrod, 45.0f);
            myPane.Chart.Fill.Type = FillType.None;
            myPane.Legend.Position = LegendPos.Float;
            myPane.Legend.Location = new Location(0f, 0f, CoordType.PaneFraction, AlignH.Left, AlignV.Top);
            myPane.Legend.FontSpec.Size = 15f;
            myPane.Legend.IsHStack = false;
            double[] chartCost = new double[counter];
            string[] chartLabel = new string[counter];

            for (int i = 0; i < counter; i++)
            {
                chartCost[i] = double.Parse(dataGridView2.Rows[i].Cells[2].Value.ToString());
                chartLabel[i] = dataGridView2.Rows[i].Cells[1].Value.ToString();
            }
            PieItem[] pp = myPane.AddPieSlices(chartCost, chartLabel);

            for (int i = 0; i < pp.Length; i++)
            {
                pp[i].LabelType = PieLabelType.Name_Value_Percent;
                pp[i].LabelDetail.FontSpec.Size = 15f;
            }
            zgc.AxisChange();
            zgc.Refresh();
            */
            #endregion

            #region 方法2 --> 有篩選重複值
            Xdata.Clear(); Ydata.Clear();
            zgc.GraphPane.CurveList.Clear();
            GraphPane myPane = zgc.GraphPane;
            counter = dataGridView.RowCount - 1;
            string temp;

            #region 畫圖美觀
            myPane.Title.Text = title;
            myPane.Title.FontSpec.Size = 24f;
            myPane.Title.FontSpec.Family = "微軟正黑體";

            myPane.Fill = new Fill(Color.White, Color.Goldenrod, 45.0f);
            myPane.Chart.Fill.Type = FillType.None;
            myPane.Legend.Position = LegendPos.Float;
            myPane.Legend.Location = new Location(0f, 0f, CoordType.PaneFraction, AlignH.Left, AlignV.Top);
            myPane.Legend.FontSpec.Size = 15f;
            myPane.Legend.IsHStack = false;
            #endregion

            for (int i = 0; i < counter; i++)
            {
                temp = dataGridView.Rows[i].Cells[0].Value.ToString();
                if (Xdata.Contains(temp)) { Ydata[Xdata.IndexOf(temp)] += Double.Parse(dataGridView.Rows[i].Cells[10].Value.ToString()); }
                else
                {
                    Xdata.Add(temp);
                    Ydata.Add(Double.Parse(dataGridView.Rows[i].Cells[10].Value.ToString()));
                }
            }

            string[] chartLabel = new string[Xdata.Count];
            double[] chartCost = new double[Ydata.Count];

            for (int i = 0; i < chartLabel.Length; i++)
            {
                chartLabel[i] = Xdata[i];
                chartCost[i] = Ydata[i];
            }
            PieItem[] pp = myPane.AddPieSlices(chartCost, chartLabel);
            for (int i = 0; i < pp.Length; i++)
            {
                pp[i].LabelType = PieLabelType.Name_Value_Percent;
                pp[i].LabelDetail.FontSpec.Size = 15f;
            }
            zgc.AxisChange();
            zgc.Refresh();
            #endregion
        }
        #endregion

        #region 長條
        public void createBar(ZedGraphControl zgc, String category, String quantity, String title, DataGridView dataGridView)
        {
            #region 方法1 --> 沒有篩選重複值  不用!!!
            /*
            GraphPane myPane = zgc.GraphPane;
            counter = dataGridView1.RowCount - 1;

            string[] x = new string[counter];
            double[] y = new double[counter];

            for (int i = 0; i < counter; i++)
            {
                x[i] = dataGridView1.Rows[i].Cells[0].Value.ToString();
                y[i] = Double.Parse(dataGridView1.Rows[i].Cells[10].Value.ToString());
            }
            myPane.Chart.Fill.Type = FillType.None;
            myPane.Fill = new Fill(Color.White, Color.FromArgb(255, 255, 200), 90F);
            myPane.XAxis.Scale.TextLabels = x;
            myPane.XAxis.Type = AxisType.Text;


            BarItem barChart = myPane.AddBar("銷售總額", null, y, Color.FromArgb(random.Next(0, 255), random.Next(0, 255), random.Next(0, 255)));
            barChart.Bar.Fill = new Fill(Color.FromArgb(random.Next(0, 255), random.Next(0, 255), random.Next(0, 255)),
                Color.FromArgb(random.Next(0, 255), random.Next(0, 255), random.Next(0, 255)),
                Color.FromArgb(random.Next(0, 255), random.Next(0, 255), random.Next(0, 255)));

            myPane.Title.Text = title;
            myPane.XAxis.Title.Text = category;
            myPane.YAxis.Title.Text = quantity;

            zgc.Refresh();
            zgc.AxisChange();
            Curve.Clear();
            */
            #endregion

            #region 方法2 --> 有篩選重複值
            Xdata.Clear(); Ydata.Clear();
            GraphPane myPane = zgc.GraphPane;
            counter = dataGridView.RowCount - 1;
            string temp;

            for (int i = 0; i < counter; i++)
            {
                temp = dataGridView.Rows[i].Cells[0].Value.ToString();
                if (Xdata.Contains(temp)) { Ydata[Xdata.IndexOf(temp)] += Double.Parse(dataGridView.Rows[i].Cells[10].Value.ToString()); }
                else
                {
                    Xdata.Add(temp);
                    Ydata.Add(Double.Parse(dataGridView.Rows[i].Cells[10].Value.ToString()));
                }
            }
            string[] x = new string[Xdata.Count];
            double[] y = new double[Ydata.Count];

            for (int i = 0; i < x.Length; i++)
            {
                x[i] = Xdata[i];
                y[i] = Ydata[i];
            }

            #region 畫圖美觀部分
            myPane.Chart.Fill.Type = FillType.None;
            myPane.Fill = new Fill(Color.White, Color.FromArgb(255, 255, 200), 90F);

            myPane.XAxis.Scale.TextLabels = x;
            myPane.XAxis.Type = AxisType.Text;
            myPane.XAxis.Title.Text = category;
            myPane.XAxis.Title.FontSpec.Size = 20f;
            myPane.XAxis.Title.FontSpec.Family = "微軟正黑體";

            myPane.Title.Text = title;
            myPane.Title.FontSpec.Size = 24f;
            myPane.Title.FontSpec.Family = "微軟正黑體";

            myPane.YAxis.Title.Text = quantity;
            myPane.YAxis.Title.FontSpec.Size = 20f;
            myPane.YAxis.Title.FontSpec.Family = "微軟正黑體";
            #endregion

            BarItem barChart = myPane.AddBar("銷售總額", null, y, Color.FromArgb(random.Next(0, 255), random.Next(0, 255), random.Next(0, 255)));
            barChart.Bar.Fill = new Fill(Color.FromArgb(random.Next(0, 255), random.Next(0, 255), random.Next(0, 255)),
                Color.FromArgb(random.Next(0, 255), random.Next(0, 255), random.Next(0, 255)),
                Color.FromArgb(random.Next(0, 255), random.Next(0, 255), random.Next(0, 255)));
            zgc.Refresh();
            zgc.AxisChange();
            Curve.Clear();

            #endregion
        }
        #endregion

        #endregion

        #region 離開
        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Hide();
        }
        #endregion

        #region 確認品名
        private void btnConfirmItems_Click(object sender, EventArgs e)
        {
            try
            {
                if (txtBxCategory.Text != null)
                {
                    dataGridView2.Rows.Clear();
                    finfItemByCategory();
                }
                else { MessageBox.Show("請選擇!!!"); }
            }
            catch (Exception ex) { MessageBox.Show("" + ex.Message); }
        }
        #endregion

        #region 長條圖顯示
        private void btnBarChart_Click(object sender, EventArgs e)
        {
            ZGC.GraphPane.CurveList.Clear();
            ZGC.GraphPane.GraphObjList.Clear();
            createBar(ZGC, "日期", "營業總額", "長條圖", dataGridView1);
        }

        private void btnBarChartCategory_Click(object sender, EventArgs e)
        {
            ZGC.GraphPane.CurveList.Clear();
            ZGC.GraphPane.GraphObjList.Clear();
            string category = txtBxCategory.Text;
            createBar(ZGC, "種類", "營業額", "長條圖", dataGridView2);
        }
        #endregion

        #region 圓餅圖顯示
        private void btnPieChart_Click(object sender, EventArgs e)
        {
            ZGCPie.GraphPane.CurveList.Clear();
            ZGCPie.GraphPane.GraphObjList.Clear();
            GraphPane myPane = ZGCPie.GraphPane;
            createChart(ZGCPie, "圓餅圖\n營業總額", dataGridView1);
        }

        private void btnPieChartCategory_Click(object sender, EventArgs e)
        {
            ZGCPie.GraphPane.CurveList.Clear();
            ZGCPie.GraphPane.GraphObjList.Clear();
            GraphPane myPane = ZGCPie.GraphPane;
            string category = txtBxCategory.Text;
            createChart(ZGCPie, "圓餅圖\n" + category + "營業額", dataGridView2);
        }
        #endregion

        #region 折線圖顯示
        private void btnLineChart_Click(object sender, EventArgs e)
        {
            ZGC.GraphPane.CurveList.Clear();
            ZGC.GraphPane.GraphObjList.Clear();
            createLine(ZGC, "日期", "營業總額", "長條圖", dataGridView1);
        }

        private void btnLineChartCategory_Click(object sender, EventArgs e)
        {
            ZGC.GraphPane.CurveList.Clear();
            ZGC.GraphPane.GraphObjList.Clear();
            string category = txtBxCategory.Text;
            createLine(ZGC, "種類", "營業額", "長條圖", dataGridView2);
        }
        #endregion

        #region 點擊選取
        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            try { txtBxCategory.Text = dataGridView1.Rows[e.RowIndex].Cells[2].Value.ToString(); }
            catch (Exception ex) { MessageBox.Show(ex.Message); }
        }
        #endregion

        #region 透過種類輸出
        private void finfItemByCategory()
        {
            try
            {
                int counter = 0;
                for (int i = 0; i < dataGridView1.RowCount - 1; i++)
                {
                    if (dataGridView1.Rows[i].Cells[2].Value.ToString() == txtBxCategory.Text)
                    {
                        //MessageBox.Show(dataGridView1.Rows[i].Cells[3].Value.ToString());
                        dataGridView2.Rows.Add(dataGridView1.Rows[i].Cells[3].Value.ToString(),
                            dataGridView1.Rows[i].Cells[1].Value.ToString(),
                            dataGridView1.Rows[i].Cells[2].Value.ToString(),
                            dataGridView1.Rows[i].Cells[0].Value.ToString(),
                            dataGridView1.Rows[i].Cells[4].Value.ToString(),
                            dataGridView1.Rows[i].Cells[5].Value.ToString(),
                            dataGridView1.Rows[i].Cells[6].Value.ToString(),
                            dataGridView1.Rows[i].Cells[7].Value.ToString(),
                            dataGridView1.Rows[i].Cells[8].Value.ToString(),
                            dataGridView1.Rows[i].Cells[9].Value.ToString(),
                            dataGridView1.Rows[i].Cells[10].Value.ToString());
                        counter++;
                    }
                    else { }
                }
            }
            catch (Exception ex) { MessageBox.Show(ex.Message); }
        }
        #endregion

        #region 選擇日期
        private void dateTimePicker_ValueChanged(object sender, EventArgs e)
        {
            String Sql = "SELECT * FROM transaction1 WHERE date like '" + dateTimePicker.Value.ToShortDateString() + "%'";
            SqlConnection conn = new SqlConnection(@"server=usingnamespace.ddns.net;database=ordering;uid=wei;pwd=1212");
            conn.Open();

            SqlDataAdapter sqlda = new SqlDataAdapter(Sql, conn);
            DataSet ds = new DataSet("ds_transaction1");
            sqlda.Fill(ds, "ds_transaction1");
            transaction1BindingSource.DataSource = ds.Tables[0];
            dataGridView1.DataSource = transaction1BindingSource;
            dataGridView1.AutoResizeRows();
            dataGridView1.AutoResizeColumns();
            conn.Close();
        }
        #endregion

        #region  初始資料
        private void btnTest_Click(object sender, EventArgs e)
        {
            #region 測試用
            //string temp = "";
            //foreach (DataGridViewRow v in dataGridView1.Rows)
            //{
            //    temp = v.Cells[0].Value.ToString();
            //    if (v.Cells[0].Value != null)
            //    {
            //        var count = 0;
            //        foreach (DataGridViewRow v2 in dataGridView1.Rows)
            //        {
            //            if (v2.Cells[0].Value != null)
            //            {
            //                if (v.Cells[0].Value.ToString().Equals(v2.Cells[0].Value.ToString()))
            //                    count++;
            //            }
            //        }
            //        if (count < dataGridView1.RowCount)
            //        {
            //            MessageBox.Show("有重复，重复的内容是:【" + v.Cells[0].Value + "】");
            //            continue;
            //        }
            //    }
            //}
            #endregion

            ConnectDB();
        }

        #region 原始資料庫連結
        private void ConnectDB()
        {
            String Sql = "SELECT * FROM transaction1";
            SqlConnection conn = new SqlConnection(@"server=usingnamespace.ddns.net;database=ordering;uid=wei;pwd=1212");
            conn.Open();

            SqlDataAdapter sqlda = new SqlDataAdapter(Sql, conn);
            DataSet ds = new DataSet("ds_transaction1");
            sqlda.Fill(ds, "ds_transaction1");
            transaction1BindingSource.DataSource = ds.Tables[0];
            dataGridView1.DataSource = transaction1BindingSource;
            dataGridView1.AutoResizeRows();
            dataGridView1.AutoResizeColumns();
            conn.Close();
        }
        #endregion

        #endregion
    }
}
