﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _2519_FinalProject
{
    public partial class FrmQuery : Form
    {
        public FrmQuery()
        {
            InitializeComponent();
        }

        #region 連接資料庫
        private void FrmQuery_Load(object sender, EventArgs e)
        {
            // TODO: 這行程式碼會將資料載入 'orderingDataSet8.transaction1' 資料表。您可以視需要進行移動或移除。
            this.transaction1TableAdapter.Fill(this.orderingDataSet8.transaction1);
            bindingNavigator1.BindingSource = transaction1BindingSource;
        }
        #endregion

        #region 點擊選取
        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            try { txtBxOrderNum.Text = dataGridView1.Rows[e.RowIndex].Cells[1].Value.ToString(); }
            catch (Exception ex) { MessageBox.Show(ex.Message); }
        }
        #endregion
        
        #region 透過訂單編號輸出品項
        private void findTransactionByOrderNum()
        {
            try
            {
                for (int i = 0; i < dataGridView1.RowCount - 1; i++)
                {
                    if (dataGridView1.Rows[i].Cells[1].Value.ToString() == txtBxOrderNum.Text)
                    {
                        //MessageBox.Show(dataGridView1.Rows[i].Cells[3].Value.ToString());
                        dataGridView2.Rows.Add(dataGridView1.Rows[i].Cells[0].Value.ToString(),
                            dataGridView1.Rows[i].Cells[1].Value.ToString(),
                            dataGridView1.Rows[i].Cells[2].Value.ToString(),
                            dataGridView1.Rows[i].Cells[3].Value.ToString(),
                            dataGridView1.Rows[i].Cells[4].Value.ToString(),
                            dataGridView1.Rows[i].Cells[5].Value.ToString(),
                            dataGridView1.Rows[i].Cells[6].Value.ToString(),
                            dataGridView1.Rows[i].Cells[7].Value.ToString(), 
                            dataGridView1.Rows[i].Cells[8].Value.ToString(),
                            dataGridView1.Rows[i].Cells[9].Value.ToString(), 
                            dataGridView1.Rows[i].Cells[10].Value.ToString());
                    }
                    else {  }
                }
            }
            catch (Exception ex) { MessageBox.Show(ex.Message); }
        }
        #endregion

        #region 確認訂單編號
        private void btnConfirmOrderNum_Click(object sender, EventArgs e)
        {
            dataGridView2.Rows.Clear();
            findTransactionByOrderNum();
            Total();
        }
        #endregion

        #region 總價方法
        private void Total()
        {
            int total = 0;
            for (int i = 0; i < dataGridView2.Rows.Count; i++)
            {
                DataGridViewRow row = dataGridView2.Rows[i];
                if (row.Cells[0].Value != null)
                    total += int.Parse(row.Cells[10].Value.ToString());
            }
            txtBxTotalPrice.Text = total.ToString();
        }
        #endregion

        #region 離開
        private void btnExit_Click_1(object sender, EventArgs e)
        {
            this.Hide();
        }
        #endregion
    }
}
