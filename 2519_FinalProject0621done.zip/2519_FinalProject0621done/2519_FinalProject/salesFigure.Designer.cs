﻿namespace _2519_FinalProject
{
    partial class salesFigure
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(salesFigure));
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle6 = new System.Windows.Forms.DataGridViewCellStyle();
            this.btnConfirmItems = new System.Windows.Forms.Button();
            this.txtBxCategory = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.btnExit = new System.Windows.Forms.Button();
            this.ZGCPie = new ZedGraph.ZedGraphControl();
            this.ZGC = new ZedGraph.ZedGraphControl();
            this.bindingNavigator = new System.Windows.Forms.BindingNavigator(this.components);
            this.bindingNavigatorAddNewItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorCountItem = new System.Windows.Forms.ToolStripLabel();
            this.bindingNavigatorDeleteItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMoveFirstItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMovePreviousItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorPositionItem = new System.Windows.Forms.ToolStripTextBox();
            this.bindingNavigatorSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorMoveNextItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMoveLastItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.交易紀錄 = new System.Windows.Forms.Label();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.dateDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.orderNumDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.categoryDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.itemsDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.largeDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.cheeseDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.riceNoodlesDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.cuttlePenneDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.priceDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.quantityDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.totalDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.transaction1BindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.orderingDataSet7 = new _2519_FinalProject.orderingDataSet7();
            this.transaction1TableAdapter = new _2519_FinalProject.orderingDataSet7TableAdapters.transaction1TableAdapter();
            this.dateTimePicker = new System.Windows.Forms.DateTimePicker();
            this.btnTest = new System.Windows.Forms.Button();
            this.dataGridView2 = new System.Windows.Forms.DataGridView();
            this.Column4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column6 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column7 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column8 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column9 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column10 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column11 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.gpBxTotal = new System.Windows.Forms.GroupBox();
            this.RdBtnLineChart = new System.Windows.Forms.RadioButton();
            this.RdBtnPieChart = new System.Windows.Forms.RadioButton();
            this.RdBtnBarChart = new System.Windows.Forms.RadioButton();
            this.gbBxcategory = new System.Windows.Forms.GroupBox();
            this.RdBtnLineChartCategory = new System.Windows.Forms.RadioButton();
            this.RdBtnPieChartCategory = new System.Windows.Forms.RadioButton();
            this.RdBtnBarChartCategory = new System.Windows.Forms.RadioButton();
            this.BtnShow = new System.Windows.Forms.Button();
            this.BtnShowCategory = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.bindingNavigator)).BeginInit();
            this.bindingNavigator.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.transaction1BindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.orderingDataSet7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).BeginInit();
            this.gpBxTotal.SuspendLayout();
            this.gbBxcategory.SuspendLayout();
            this.SuspendLayout();
            // 
            // btnConfirmItems
            // 
            this.btnConfirmItems.BackColor = System.Drawing.Color.Aquamarine;
            this.btnConfirmItems.Location = new System.Drawing.Point(463, 297);
            this.btnConfirmItems.Name = "btnConfirmItems";
            this.btnConfirmItems.Size = new System.Drawing.Size(78, 25);
            this.btnConfirmItems.TabIndex = 22;
            this.btnConfirmItems.Text = "確認";
            this.btnConfirmItems.UseVisualStyleBackColor = false;
            this.btnConfirmItems.Click += new System.EventHandler(this.btnConfirmItems_Click);
            // 
            // txtBxCategory
            // 
            this.txtBxCategory.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
            this.txtBxCategory.Location = new System.Drawing.Point(466, 264);
            this.txtBxCategory.Name = "txtBxCategory";
            this.txtBxCategory.Size = new System.Drawing.Size(75, 27);
            this.txtBxCategory.TabIndex = 20;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(462, 242);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(84, 19);
            this.label1.TabIndex = 19;
            this.label1.Text = "欲分析種類";
            // 
            // btnExit
            // 
            this.btnExit.BackColor = System.Drawing.Color.Crimson;
            this.btnExit.Font = new System.Drawing.Font("微軟正黑體", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.btnExit.Location = new System.Drawing.Point(365, 31);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(87, 37);
            this.btnExit.TabIndex = 15;
            this.btnExit.Text = "離開";
            this.btnExit.UseVisualStyleBackColor = false;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
            // 
            // ZGCPie
            // 
            this.ZGCPie.Location = new System.Drawing.Point(1020, 40);
            this.ZGCPie.Margin = new System.Windows.Forms.Padding(8, 10, 8, 10);
            this.ZGCPie.Name = "ZGCPie";
            this.ZGCPie.ScrollGrace = 0D;
            this.ZGCPie.ScrollMaxX = 0D;
            this.ZGCPie.ScrollMaxY = 0D;
            this.ZGCPie.ScrollMaxY2 = 0D;
            this.ZGCPie.ScrollMinX = 0D;
            this.ZGCPie.ScrollMinY = 0D;
            this.ZGCPie.ScrollMinY2 = 0D;
            this.ZGCPie.Size = new System.Drawing.Size(450, 450);
            this.ZGCPie.TabIndex = 24;
            this.ZGCPie.UseExtendedPrintDialog = true;
            // 
            // ZGC
            // 
            this.ZGC.Location = new System.Drawing.Point(556, 39);
            this.ZGC.Margin = new System.Windows.Forms.Padding(6);
            this.ZGC.Name = "ZGC";
            this.ZGC.ScrollGrace = 0D;
            this.ZGC.ScrollMaxX = 0D;
            this.ZGC.ScrollMaxY = 0D;
            this.ZGC.ScrollMaxY2 = 0D;
            this.ZGC.ScrollMinX = 0D;
            this.ZGC.ScrollMinY = 0D;
            this.ZGC.ScrollMinY2 = 0D;
            this.ZGC.Size = new System.Drawing.Size(450, 450);
            this.ZGC.TabIndex = 23;
            this.ZGC.UseExtendedPrintDialog = true;
            // 
            // bindingNavigator
            // 
            this.bindingNavigator.AddNewItem = this.bindingNavigatorAddNewItem;
            this.bindingNavigator.CountItem = this.bindingNavigatorCountItem;
            this.bindingNavigator.DeleteItem = this.bindingNavigatorDeleteItem;
            this.bindingNavigator.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.bindingNavigatorMoveFirstItem,
            this.bindingNavigatorMovePreviousItem,
            this.bindingNavigatorSeparator,
            this.bindingNavigatorPositionItem,
            this.bindingNavigatorCountItem,
            this.bindingNavigatorSeparator1,
            this.bindingNavigatorMoveNextItem,
            this.bindingNavigatorMoveLastItem,
            this.bindingNavigatorSeparator2,
            this.bindingNavigatorAddNewItem,
            this.bindingNavigatorDeleteItem});
            this.bindingNavigator.Location = new System.Drawing.Point(0, 0);
            this.bindingNavigator.MoveFirstItem = this.bindingNavigatorMoveFirstItem;
            this.bindingNavigator.MoveLastItem = this.bindingNavigatorMoveLastItem;
            this.bindingNavigator.MoveNextItem = this.bindingNavigatorMoveNextItem;
            this.bindingNavigator.MovePreviousItem = this.bindingNavigatorMovePreviousItem;
            this.bindingNavigator.Name = "bindingNavigator";
            this.bindingNavigator.PositionItem = this.bindingNavigatorPositionItem;
            this.bindingNavigator.Size = new System.Drawing.Size(1484, 25);
            this.bindingNavigator.TabIndex = 25;
            this.bindingNavigator.Text = "bindingNavigator1";
            // 
            // bindingNavigatorAddNewItem
            // 
            this.bindingNavigatorAddNewItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorAddNewItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorAddNewItem.Image")));
            this.bindingNavigatorAddNewItem.Name = "bindingNavigatorAddNewItem";
            this.bindingNavigatorAddNewItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorAddNewItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorAddNewItem.Text = "加入新的";
            // 
            // bindingNavigatorCountItem
            // 
            this.bindingNavigatorCountItem.Name = "bindingNavigatorCountItem";
            this.bindingNavigatorCountItem.Size = new System.Drawing.Size(27, 22);
            this.bindingNavigatorCountItem.Text = "/{0}";
            this.bindingNavigatorCountItem.ToolTipText = "項目總數";
            // 
            // bindingNavigatorDeleteItem
            // 
            this.bindingNavigatorDeleteItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorDeleteItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorDeleteItem.Image")));
            this.bindingNavigatorDeleteItem.Name = "bindingNavigatorDeleteItem";
            this.bindingNavigatorDeleteItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorDeleteItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorDeleteItem.Text = "刪除";
            // 
            // bindingNavigatorMoveFirstItem
            // 
            this.bindingNavigatorMoveFirstItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveFirstItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveFirstItem.Image")));
            this.bindingNavigatorMoveFirstItem.Name = "bindingNavigatorMoveFirstItem";
            this.bindingNavigatorMoveFirstItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveFirstItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveFirstItem.Text = "移到最前面";
            // 
            // bindingNavigatorMovePreviousItem
            // 
            this.bindingNavigatorMovePreviousItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMovePreviousItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMovePreviousItem.Image")));
            this.bindingNavigatorMovePreviousItem.Name = "bindingNavigatorMovePreviousItem";
            this.bindingNavigatorMovePreviousItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMovePreviousItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMovePreviousItem.Text = "移到上一個";
            // 
            // bindingNavigatorSeparator
            // 
            this.bindingNavigatorSeparator.Name = "bindingNavigatorSeparator";
            this.bindingNavigatorSeparator.Size = new System.Drawing.Size(6, 25);
            // 
            // bindingNavigatorPositionItem
            // 
            this.bindingNavigatorPositionItem.AccessibleName = "位置";
            this.bindingNavigatorPositionItem.AutoSize = false;
            this.bindingNavigatorPositionItem.Name = "bindingNavigatorPositionItem";
            this.bindingNavigatorPositionItem.Size = new System.Drawing.Size(45, 23);
            this.bindingNavigatorPositionItem.Text = "0";
            this.bindingNavigatorPositionItem.ToolTipText = "目前的位置";
            // 
            // bindingNavigatorSeparator1
            // 
            this.bindingNavigatorSeparator1.Name = "bindingNavigatorSeparator1";
            this.bindingNavigatorSeparator1.Size = new System.Drawing.Size(6, 25);
            // 
            // bindingNavigatorMoveNextItem
            // 
            this.bindingNavigatorMoveNextItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveNextItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveNextItem.Image")));
            this.bindingNavigatorMoveNextItem.Name = "bindingNavigatorMoveNextItem";
            this.bindingNavigatorMoveNextItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveNextItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveNextItem.Text = "移到下一個";
            // 
            // bindingNavigatorMoveLastItem
            // 
            this.bindingNavigatorMoveLastItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveLastItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveLastItem.Image")));
            this.bindingNavigatorMoveLastItem.Name = "bindingNavigatorMoveLastItem";
            this.bindingNavigatorMoveLastItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveLastItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveLastItem.Text = "移到最後面";
            // 
            // bindingNavigatorSeparator2
            // 
            this.bindingNavigatorSeparator2.Name = "bindingNavigatorSeparator2";
            this.bindingNavigatorSeparator2.Size = new System.Drawing.Size(6, 25);
            // 
            // 交易紀錄
            // 
            this.交易紀錄.AutoSize = true;
            this.交易紀錄.Location = new System.Drawing.Point(8, 46);
            this.交易紀錄.Name = "交易紀錄";
            this.交易紀錄.Size = new System.Drawing.Size(69, 19);
            this.交易紀錄.TabIndex = 26;
            this.交易紀錄.Text = "交易紀錄";
            // 
            // dataGridView1
            // 
            this.dataGridView1.AllowUserToOrderColumns = true;
            this.dataGridView1.AutoGenerateColumns = false;
            this.dataGridView1.BackgroundColor = System.Drawing.Color.IndianRed;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dateDataGridViewTextBoxColumn,
            this.orderNumDataGridViewTextBoxColumn,
            this.categoryDataGridViewTextBoxColumn,
            this.itemsDataGridViewTextBoxColumn,
            this.largeDataGridViewTextBoxColumn,
            this.cheeseDataGridViewTextBoxColumn,
            this.riceNoodlesDataGridViewTextBoxColumn,
            this.cuttlePenneDataGridViewTextBoxColumn,
            this.priceDataGridViewTextBoxColumn,
            this.quantityDataGridViewTextBoxColumn,
            this.totalDataGridViewTextBoxColumn});
            this.dataGridView1.DataSource = this.transaction1BindingSource;
            this.dataGridView1.Location = new System.Drawing.Point(12, 71);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowTemplate.Height = 24;
            this.dataGridView1.Size = new System.Drawing.Size(440, 205);
            this.dataGridView1.TabIndex = 27;
            this.dataGridView1.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellContentClick);
            // 
            // dateDataGridViewTextBoxColumn
            // 
            this.dateDataGridViewTextBoxColumn.DataPropertyName = "date";
            this.dateDataGridViewTextBoxColumn.HeaderText = "日期";
            this.dateDataGridViewTextBoxColumn.Name = "dateDataGridViewTextBoxColumn";
            // 
            // orderNumDataGridViewTextBoxColumn
            // 
            this.orderNumDataGridViewTextBoxColumn.DataPropertyName = "OrderNum";
            this.orderNumDataGridViewTextBoxColumn.HeaderText = "訂單編號";
            this.orderNumDataGridViewTextBoxColumn.Name = "orderNumDataGridViewTextBoxColumn";
            // 
            // categoryDataGridViewTextBoxColumn
            // 
            this.categoryDataGridViewTextBoxColumn.DataPropertyName = "category";
            this.categoryDataGridViewTextBoxColumn.HeaderText = "種類";
            this.categoryDataGridViewTextBoxColumn.Name = "categoryDataGridViewTextBoxColumn";
            // 
            // itemsDataGridViewTextBoxColumn
            // 
            this.itemsDataGridViewTextBoxColumn.DataPropertyName = "items";
            this.itemsDataGridViewTextBoxColumn.HeaderText = "品名";
            this.itemsDataGridViewTextBoxColumn.Name = "itemsDataGridViewTextBoxColumn";
            // 
            // largeDataGridViewTextBoxColumn
            // 
            this.largeDataGridViewTextBoxColumn.DataPropertyName = "large";
            this.largeDataGridViewTextBoxColumn.HeaderText = "加大";
            this.largeDataGridViewTextBoxColumn.Name = "largeDataGridViewTextBoxColumn";
            // 
            // cheeseDataGridViewTextBoxColumn
            // 
            this.cheeseDataGridViewTextBoxColumn.DataPropertyName = "cheese";
            this.cheeseDataGridViewTextBoxColumn.HeaderText = "加起司";
            this.cheeseDataGridViewTextBoxColumn.Name = "cheeseDataGridViewTextBoxColumn";
            // 
            // riceNoodlesDataGridViewTextBoxColumn
            // 
            this.riceNoodlesDataGridViewTextBoxColumn.DataPropertyName = "RiceNoodles";
            this.riceNoodlesDataGridViewTextBoxColumn.HeaderText = "麵/飯";
            this.riceNoodlesDataGridViewTextBoxColumn.Name = "riceNoodlesDataGridViewTextBoxColumn";
            // 
            // cuttlePenneDataGridViewTextBoxColumn
            // 
            this.cuttlePenneDataGridViewTextBoxColumn.DataPropertyName = "CuttlePenne";
            this.cuttlePenneDataGridViewTextBoxColumn.HeaderText = "墨魚斜管";
            this.cuttlePenneDataGridViewTextBoxColumn.Name = "cuttlePenneDataGridViewTextBoxColumn";
            // 
            // priceDataGridViewTextBoxColumn
            // 
            this.priceDataGridViewTextBoxColumn.DataPropertyName = "price";
            this.priceDataGridViewTextBoxColumn.HeaderText = "單價";
            this.priceDataGridViewTextBoxColumn.Name = "priceDataGridViewTextBoxColumn";
            // 
            // quantityDataGridViewTextBoxColumn
            // 
            this.quantityDataGridViewTextBoxColumn.DataPropertyName = "quantity";
            this.quantityDataGridViewTextBoxColumn.HeaderText = "數量";
            this.quantityDataGridViewTextBoxColumn.Name = "quantityDataGridViewTextBoxColumn";
            // 
            // totalDataGridViewTextBoxColumn
            // 
            this.totalDataGridViewTextBoxColumn.DataPropertyName = "total";
            this.totalDataGridViewTextBoxColumn.HeaderText = "小計";
            this.totalDataGridViewTextBoxColumn.Name = "totalDataGridViewTextBoxColumn";
            // 
            // transaction1BindingSource
            // 
            this.transaction1BindingSource.DataMember = "transaction1";
            this.transaction1BindingSource.DataSource = this.orderingDataSet7;
            // 
            // orderingDataSet7
            // 
            this.orderingDataSet7.DataSetName = "orderingDataSet7";
            this.orderingDataSet7.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // transaction1TableAdapter
            // 
            this.transaction1TableAdapter.ClearBeforeFill = true;
            // 
            // dateTimePicker
            // 
            this.dateTimePicker.Location = new System.Drawing.Point(83, 41);
            this.dateTimePicker.Name = "dateTimePicker";
            this.dateTimePicker.Size = new System.Drawing.Size(154, 27);
            this.dateTimePicker.TabIndex = 28;
            this.dateTimePicker.ValueChanged += new System.EventHandler(this.dateTimePicker_ValueChanged);
            // 
            // btnTest
            // 
            this.btnTest.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.btnTest.Location = new System.Drawing.Point(243, 42);
            this.btnTest.Name = "btnTest";
            this.btnTest.Size = new System.Drawing.Size(87, 27);
            this.btnTest.TabIndex = 29;
            this.btnTest.Text = "原始記錄";
            this.btnTest.UseVisualStyleBackColor = false;
            this.btnTest.Click += new System.EventHandler(this.btnTest_Click);
            // 
            // dataGridView2
            // 
            dataGridViewCellStyle5.Font = new System.Drawing.Font("微軟正黑體", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.dataGridView2.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle5;
            this.dataGridView2.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.dataGridView2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView2.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Column4,
            this.Column2,
            this.Column3,
            this.Column1,
            this.Column5,
            this.Column6,
            this.Column7,
            this.Column8,
            this.Column9,
            this.Column10,
            this.Column11});
            this.dataGridView2.Location = new System.Drawing.Point(12, 284);
            this.dataGridView2.Margin = new System.Windows.Forms.Padding(5);
            this.dataGridView2.Name = "dataGridView2";
            dataGridViewCellStyle6.Font = new System.Drawing.Font("微軟正黑體", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.dataGridView2.RowsDefaultCellStyle = dataGridViewCellStyle6;
            this.dataGridView2.RowTemplate.Height = 24;
            this.dataGridView2.Size = new System.Drawing.Size(440, 205);
            this.dataGridView2.TabIndex = 30;
            // 
            // Column4
            // 
            this.Column4.HeaderText = "品名";
            this.Column4.Name = "Column4";
            // 
            // Column2
            // 
            this.Column2.HeaderText = "訂單編號";
            this.Column2.Name = "Column2";
            // 
            // Column3
            // 
            this.Column3.HeaderText = "種類";
            this.Column3.Name = "Column3";
            // 
            // Column1
            // 
            this.Column1.HeaderText = "日期";
            this.Column1.Name = "Column1";
            // 
            // Column5
            // 
            this.Column5.HeaderText = "加大";
            this.Column5.Name = "Column5";
            // 
            // Column6
            // 
            this.Column6.HeaderText = "加起司";
            this.Column6.Name = "Column6";
            // 
            // Column7
            // 
            this.Column7.HeaderText = "麵/飯";
            this.Column7.Name = "Column7";
            // 
            // Column8
            // 
            this.Column8.HeaderText = "墨魚/斜管";
            this.Column8.Name = "Column8";
            // 
            // Column9
            // 
            this.Column9.HeaderText = "單價";
            this.Column9.Name = "Column9";
            // 
            // Column10
            // 
            this.Column10.HeaderText = "數量";
            this.Column10.Name = "Column10";
            // 
            // Column11
            // 
            this.Column11.HeaderText = "小計";
            this.Column11.Name = "Column11";
            // 
            // gpBxTotal
            // 
            this.gpBxTotal.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.gpBxTotal.Controls.Add(this.RdBtnLineChart);
            this.gpBxTotal.Controls.Add(this.RdBtnPieChart);
            this.gpBxTotal.Controls.Add(this.RdBtnBarChart);
            this.gpBxTotal.Location = new System.Drawing.Point(460, 71);
            this.gpBxTotal.Name = "gpBxTotal";
            this.gpBxTotal.Size = new System.Drawing.Size(87, 125);
            this.gpBxTotal.TabIndex = 31;
            this.gpBxTotal.TabStop = false;
            this.gpBxTotal.Text = "營業總額";
            // 
            // RdBtnLineChart
            // 
            this.RdBtnLineChart.AutoSize = true;
            this.RdBtnLineChart.Location = new System.Drawing.Point(6, 80);
            this.RdBtnLineChart.Name = "RdBtnLineChart";
            this.RdBtnLineChart.Size = new System.Drawing.Size(72, 23);
            this.RdBtnLineChart.TabIndex = 2;
            this.RdBtnLineChart.TabStop = true;
            this.RdBtnLineChart.Text = "折線圖";
            this.RdBtnLineChart.UseVisualStyleBackColor = true;
            // 
            // RdBtnPieChart
            // 
            this.RdBtnPieChart.AutoSize = true;
            this.RdBtnPieChart.Location = new System.Drawing.Point(6, 51);
            this.RdBtnPieChart.Name = "RdBtnPieChart";
            this.RdBtnPieChart.Size = new System.Drawing.Size(72, 23);
            this.RdBtnPieChart.TabIndex = 1;
            this.RdBtnPieChart.TabStop = true;
            this.RdBtnPieChart.Text = "圓餅圖";
            this.RdBtnPieChart.UseVisualStyleBackColor = true;
            // 
            // RdBtnBarChart
            // 
            this.RdBtnBarChart.AutoSize = true;
            this.RdBtnBarChart.Checked = true;
            this.RdBtnBarChart.Location = new System.Drawing.Point(6, 22);
            this.RdBtnBarChart.Name = "RdBtnBarChart";
            this.RdBtnBarChart.Size = new System.Drawing.Size(72, 23);
            this.RdBtnBarChart.TabIndex = 0;
            this.RdBtnBarChart.TabStop = true;
            this.RdBtnBarChart.Text = "長條圖";
            this.RdBtnBarChart.UseVisualStyleBackColor = true;
            // 
            // gbBxcategory
            // 
            this.gbBxcategory.BackColor = System.Drawing.Color.Gray;
            this.gbBxcategory.Controls.Add(this.RdBtnLineChartCategory);
            this.gbBxcategory.Controls.Add(this.RdBtnPieChartCategory);
            this.gbBxcategory.Controls.Add(this.RdBtnBarChartCategory);
            this.gbBxcategory.Location = new System.Drawing.Point(460, 328);
            this.gbBxcategory.Name = "gbBxcategory";
            this.gbBxcategory.Size = new System.Drawing.Size(87, 119);
            this.gbBxcategory.TabIndex = 32;
            this.gbBxcategory.TabStop = false;
            this.gbBxcategory.Text = "種類銷售";
            // 
            // RdBtnLineChartCategory
            // 
            this.RdBtnLineChartCategory.AutoSize = true;
            this.RdBtnLineChartCategory.Location = new System.Drawing.Point(6, 84);
            this.RdBtnLineChartCategory.Name = "RdBtnLineChartCategory";
            this.RdBtnLineChartCategory.Size = new System.Drawing.Size(72, 23);
            this.RdBtnLineChartCategory.TabIndex = 5;
            this.RdBtnLineChartCategory.TabStop = true;
            this.RdBtnLineChartCategory.Text = "折線圖";
            this.RdBtnLineChartCategory.UseVisualStyleBackColor = true;
            // 
            // RdBtnPieChartCategory
            // 
            this.RdBtnPieChartCategory.AutoSize = true;
            this.RdBtnPieChartCategory.Location = new System.Drawing.Point(6, 55);
            this.RdBtnPieChartCategory.Name = "RdBtnPieChartCategory";
            this.RdBtnPieChartCategory.Size = new System.Drawing.Size(72, 23);
            this.RdBtnPieChartCategory.TabIndex = 4;
            this.RdBtnPieChartCategory.TabStop = true;
            this.RdBtnPieChartCategory.Text = "圓餅圖";
            this.RdBtnPieChartCategory.UseVisualStyleBackColor = true;
            // 
            // RdBtnBarChartCategory
            // 
            this.RdBtnBarChartCategory.AutoSize = true;
            this.RdBtnBarChartCategory.Checked = true;
            this.RdBtnBarChartCategory.Location = new System.Drawing.Point(6, 26);
            this.RdBtnBarChartCategory.Name = "RdBtnBarChartCategory";
            this.RdBtnBarChartCategory.Size = new System.Drawing.Size(72, 23);
            this.RdBtnBarChartCategory.TabIndex = 3;
            this.RdBtnBarChartCategory.TabStop = true;
            this.RdBtnBarChartCategory.Text = "長條圖";
            this.RdBtnBarChartCategory.UseVisualStyleBackColor = true;
            // 
            // BtnShow
            // 
            this.BtnShow.BackColor = System.Drawing.Color.DeepPink;
            this.BtnShow.Font = new System.Drawing.Font("微軟正黑體", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.BtnShow.Location = new System.Drawing.Point(460, 202);
            this.BtnShow.Name = "BtnShow";
            this.BtnShow.Size = new System.Drawing.Size(87, 37);
            this.BtnShow.TabIndex = 33;
            this.BtnShow.Text = "顯示總額";
            this.BtnShow.UseVisualStyleBackColor = false;
            this.BtnShow.Click += new System.EventHandler(this.BtnShow_Click);
            // 
            // BtnShowCategory
            // 
            this.BtnShowCategory.BackColor = System.Drawing.Color.DeepPink;
            this.BtnShowCategory.Font = new System.Drawing.Font("微軟正黑體", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.BtnShowCategory.Location = new System.Drawing.Point(460, 453);
            this.BtnShowCategory.Name = "BtnShowCategory";
            this.BtnShowCategory.Size = new System.Drawing.Size(87, 37);
            this.BtnShowCategory.TabIndex = 34;
            this.BtnShowCategory.Text = "種類銷售";
            this.BtnShowCategory.UseVisualStyleBackColor = false;
            this.BtnShowCategory.Click += new System.EventHandler(this.BtnShowCategory_Click);
            // 
            // salesFigure
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 19F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.ClientSize = new System.Drawing.Size(1484, 511);
            this.Controls.Add(this.BtnShowCategory);
            this.Controls.Add(this.BtnShow);
            this.Controls.Add(this.gbBxcategory);
            this.Controls.Add(this.gpBxTotal);
            this.Controls.Add(this.dataGridView2);
            this.Controls.Add(this.btnTest);
            this.Controls.Add(this.dateTimePicker);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.交易紀錄);
            this.Controls.Add(this.bindingNavigator);
            this.Controls.Add(this.ZGCPie);
            this.Controls.Add(this.ZGC);
            this.Controls.Add(this.btnConfirmItems);
            this.Controls.Add(this.txtBxCategory);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btnExit);
            this.Font = new System.Drawing.Font("微軟正黑體", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Name = "salesFigure";
            this.Text = "salesFigure";
            this.Load += new System.EventHandler(this.salesFigure_Load);
            ((System.ComponentModel.ISupportInitialize)(this.bindingNavigator)).EndInit();
            this.bindingNavigator.ResumeLayout(false);
            this.bindingNavigator.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.transaction1BindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.orderingDataSet7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).EndInit();
            this.gpBxTotal.ResumeLayout(false);
            this.gpBxTotal.PerformLayout();
            this.gbBxcategory.ResumeLayout(false);
            this.gbBxcategory.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnConfirmItems;
        private System.Windows.Forms.TextBox txtBxCategory;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnExit;
        private ZedGraph.ZedGraphControl ZGCPie;
        private ZedGraph.ZedGraphControl ZGC;
        private System.Windows.Forms.BindingNavigator bindingNavigator;
        private System.Windows.Forms.ToolStripButton bindingNavigatorAddNewItem;
        private System.Windows.Forms.ToolStripLabel bindingNavigatorCountItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorDeleteItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveFirstItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMovePreviousItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator;
        private System.Windows.Forms.ToolStripTextBox bindingNavigatorPositionItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator1;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveNextItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveLastItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator2;
        private System.Windows.Forms.Label 交易紀錄;
        private System.Windows.Forms.DataGridView dataGridView1;
        private orderingDataSet7 orderingDataSet7;
        private System.Windows.Forms.BindingSource transaction1BindingSource;
        private orderingDataSet7TableAdapters.transaction1TableAdapter transaction1TableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn dateDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn orderNumDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn categoryDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn itemsDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn largeDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn cheeseDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn riceNoodlesDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn cuttlePenneDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn priceDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn quantityDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn totalDataGridViewTextBoxColumn;
        private System.Windows.Forms.DateTimePicker dateTimePicker;
        private System.Windows.Forms.Button btnTest;
        private System.Windows.Forms.DataGridView dataGridView2;
        private System.Windows.Forms.GroupBox gpBxTotal;
        private System.Windows.Forms.GroupBox gbBxcategory;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column4;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column2;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column3;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column1;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column5;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column6;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column7;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column8;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column9;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column10;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column11;
        private System.Windows.Forms.RadioButton RdBtnLineChart;
        private System.Windows.Forms.RadioButton RdBtnPieChart;
        private System.Windows.Forms.RadioButton RdBtnBarChart;
        private System.Windows.Forms.RadioButton RdBtnLineChartCategory;
        private System.Windows.Forms.RadioButton RdBtnPieChartCategory;
        private System.Windows.Forms.RadioButton RdBtnBarChartCategory;
        private System.Windows.Forms.Button BtnShow;
        private System.Windows.Forms.Button BtnShowCategory;
    }
}