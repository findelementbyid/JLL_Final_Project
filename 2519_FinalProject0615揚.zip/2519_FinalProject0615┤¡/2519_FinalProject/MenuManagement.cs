﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _2519_FinalProject
{
    public partial class MenuManagement : Form
    {
        public MenuManagement()
        {
            InitializeComponent();
            this.ControlBox = false;
        }

        private void MenuManagement_Load(object sender, EventArgs e)
        {
            SqlConnectionStringBuilder sqlConnStrBuilder = new SqlConnectionStringBuilder("server=usingnamespace.ddns.net;database=ordering;uid=wei;pwd=1212");
            SqlConnection sqlConn = new SqlConnection(sqlConnStrBuilder.ConnectionString);
            sqlConn.Open();
            for (int i = 0; i < orderingDataSet.Tables.Count; i++)
            {
                if (orderingDataSet.Tables[i].ToString() == "employee") { continue; }
                cbxTables.Items.Add(orderingDataSet.Tables[i].ToString());
            }
            SqlDataAdapter sqlda = new SqlDataAdapter("SELECT * FROM employee", sqlConn);
            DataSet ds = new DataSet("ds_employee");
            sqlda.Fill(ds, "ds_employee");
            bindingSource2.DataSource = ds.Tables[0];
            bindingNavigator2.BindingSource = bindingSource2;
            dataGridView2.DataSource = bindingSource2;
            dataGridView2.AutoResizeRows();
            dataGridView2.AutoResizeColumns();
            bindingNavigator1.BindingSource = bindingSource2;
            sqlConn.Close();
        }

        #region DBselect
        private void DBselect()
        {
            SqlConnectionStringBuilder sqlConnStrBuilder = new SqlConnectionStringBuilder("server=usingnamespace.ddns.net;database=ordering;uid=wei;pwd=1212");
            SqlConnection sqlConn = new SqlConnection(sqlConnStrBuilder.ConnectionString);
            sqlConn.Open();
            SqlDataAdapter sqlda = new SqlDataAdapter("SELECT * FROM [employee]", sqlConn);
            DataSet ds = new DataSet("ds_employee");
            sqlda.Fill(ds, "ds_employee");
            bindingSource2.DataSource = ds.Tables[0];
            bindingNavigator1.BindingSource = bindingSource2;
            dataGridView2.DataSource = bindingSource2;
            bindingNavigator1.BindingSource = bindingSource2;
            sqlConn.Close();
        }
        #endregion
        private void cbxTables_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cbxTables.SelectedIndex == 0) { accessDB("broil"); }
            else if (cbxTables.SelectedIndex == 1) { accessDB("noodles"); }
            else if (cbxTables.SelectedIndex == 2) { accessDB("pasta"); }
            else if (cbxTables.SelectedIndex == 3) { accessDB("rice"); }
            else if (cbxTables.SelectedIndex == 4) { accessDB("soup"); }
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Hide();
        }


        private void accessDB(string element)
        {
            SqlConnectionStringBuilder sqlConnStrBuilder = new SqlConnectionStringBuilder("server=usingnamespace.ddns.net;database=ordering;uid=wei;pwd=1212");
            SqlConnection sqlConn = new SqlConnection(sqlConnStrBuilder.ConnectionString);
            sqlConn.Open();
            SqlDataAdapter sqlda = new SqlDataAdapter("SELECT * FROM " + element, sqlConn);
            DataSet ds = new DataSet("ds_" + element);
            sqlda.Fill(ds, "ds_" + element);
            bindingSource1.DataSource = ds.Tables[0];
            bindingNavigator1.BindingSource = bindingSource1;
            dataGridView1.DataSource = bindingSource1;
            dataGridView1.AutoResizeRows();
            dataGridView1.AutoResizeColumns();
            bindingNavigator1.BindingSource = bindingSource1;
            sqlConn.Close();
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            check.Delete(cbxTables.Text, txbItems.Text, txbPrice.Text);
            accessDB(cbxTables.Text);
            txbnull();
        }

        private void dataGridView1_SelectionChanged(object sender, EventArgs e)
        {
            int select_row = dataGridView1.CurrentRow.Index;
            txbItems.Text = dataGridView1.Rows[select_row].Cells[0].Value.ToString();
            txbPrice.Text = dataGridView1.Rows[select_row].Cells[1].Value.ToString();
        }
        
        private void btnUpdate_Click(object sender, EventArgs e)
        {
            check.Update(cbxTables.Text, txbItems.Text, txbPrice.Text);
            accessDB(cbxTables.Text);
            txbnull();
        }

        private void btnInsert_Click(object sender, EventArgs e)
        {
            check.Insert(cbxTables.Text, txbItems.Text, txbPrice.Text);
            accessDB(cbxTables.Text);
            txbnull();
        }

        private void btnUUpdate_Click(object sender, EventArgs e)
        {

        }

        private void dataGridView2_SelectionChanged(object sender, EventArgs e)
        {
            int select_row = dataGridView2.CurrentRow.Index;
            txbUserID.Text = dataGridView2.Rows[select_row].Cells[0].Value.ToString();
            txbPassword.Text = dataGridView2.Rows[select_row].Cells[1].Value.ToString();
        }

        private void txbnull()
        {
            txbUserID.Text = "";txbPassword.Text = "";
            txbItems.Text = "";txbPrice.Text = "";
        }

        private void btnUserUpdate_Click(object sender, EventArgs e)
        {
            check.Update(txbEmployee.Text, txbUserID.Text, txbPassword.Text);
            DBselect();
            txbnull();
        }

        private void btnUserInsert_Click(object sender, EventArgs e)
        {
            check.Insert(txbEmployee.Text, txbUserID.Text, txbPassword.Text);
            DBselect();
            txbnull();
        }

        private void btnUserDelete_Click(object sender, EventArgs e)
        {
            check.Delete(txbEmployee.Text, txbUserID.Text, txbPassword.Text);
            DBselect();
            txbnull();
        }

        private void tabControl1_SelectedIndexChanged(object sender, EventArgs e)
        {
            
        }
    }
}
