﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace _2519_FinalProject
{
    public partial class OrderSystem : Form
    {
        static int price = 0;
        int a, b;
        public OrderSystem()
        {
            InitializeComponent();
            this.ControlBox = false;
        }

        #region dataGridView2
        private void dataGridView2_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
        #endregion

        #region btnExit
        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Hide();
        }
        #endregion

        #region formLoad()
        private void formLoad()
        {
            SqlConnectionStringBuilder sqlConnStrBuilder = new SqlConnectionStringBuilder("server=usingnamespace.ddns.net;database=ordering;uid=wei;pwd=1212");
            ////sqlConnStrBuilder.DataSource = ".\\SQLEXPRESS";
            //sqlConnStrBuilder.DataSource = "usingnamespace.ddns.net";
            //sqlConnStrBuilder.UserID = "wei";
            //sqlConnStrBuilder.Password = "1212";
            //sqlConnStrBuilder.InitialCatalog = "ordering";
            //sqlConnStrBuilder.IntegratedSecurity = true;
            SqlConnection sqlConn = new SqlConnection(sqlConnStrBuilder.ConnectionString);
            sqlConn.Open();
            for (int i = 0; i < orderingDataSet.Tables.Count; i++)
            {
                if (orderingDataSet.Tables[i].ToString() == "employee") { continue; }
                cbxMenu.Items.Add(orderingDataSet.Tables[i].ToString());
            }
            sqlConn.Close();
        }
        #endregion

        #region check_items
        private void checkitems(string state)
        {
            if (state == "soup")
            { groupBox1.Visible = false; groupBox2.Visible = false; cbxCheese.Visible = false; cbxLarge.Visible = false; }
            else if (state == "rice")
            { groupBox1.Visible = false; groupBox2.Visible = false; cbxCheese.Visible = true; cbxLarge.Visible = true; }
            else if (state == "broil")
            { groupBox1.Visible = false; groupBox2.Visible = true; }
            else
            { groupBox1.Visible = true; groupBox2.Visible = false; cbxCheese.Visible = true; cbxLarge.Visible = true; }
        }
        #endregion 

        #region connect to DB
        private void accessDB(string element)
        {
            SqlConnectionStringBuilder sqlConnStrBuilder = new SqlConnectionStringBuilder("server=usingnamespace.ddns.net;database=ordering;uid=wei;pwd=1212");
            ////sqlConnStrBuilder.DataSource = ".\\SQLEXPRESS";
            //sqlConnStrBuilder.DataSource = "USINGNAMESPACE";
            //sqlConnStrBuilder.InitialCatalog = "ordering";
            //sqlConnStrBuilder.IntegratedSecurity = true;
            SqlConnection sqlConn = new SqlConnection(sqlConnStrBuilder.ConnectionString);
            sqlConn.Open();
            SqlDataAdapter sqlda = new SqlDataAdapter("SELECT * FROM " + element, sqlConn);
            DataSet ds = new DataSet("ds_" + element);
            sqlda.Fill(ds, "ds_" + element);
            bindingSource1.DataSource = ds.Tables[0];
            bindingNavigator1.BindingSource = bindingSource1;
            dataGridView1.DataSource = bindingSource1;
            dataGridView1.AutoResizeRows();
            dataGridView1.AutoResizeColumns();
            bindingNavigator1.BindingSource = bindingSource1;
            sqlConn.Close();
        }
        #endregion

        #region cbxMenu_SelectedIndexChanged
        private void cbxMenu_SelectedIndexChanged_1(object sender, EventArgs e)
        {
            cancel();
            if (cbxMenu.SelectedIndex == 0) { checkitems("broil"); accessDB("broil"); }
            else if (cbxMenu.SelectedIndex == 1) { checkitems("noodles"); accessDB("noodles"); }
            else if (cbxMenu.SelectedIndex == 2) { checkitems("pasta"); accessDB("pasta"); }
            else if (cbxMenu.SelectedIndex == 3) { checkitems("rice"); accessDB("rice"); }
            else if (cbxMenu.SelectedIndex == 4) { checkitems("soup"); accessDB("soup"); }
        }
        #endregion

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (dataGridView1.Rows[e.RowIndex].Cells[0].Value == null) return;
            txbItems.Text = dataGridView1.Rows[e.RowIndex].Cells[0].Value.ToString();
            txbPrice.Text = dataGridView1.Rows[e.RowIndex].Cells[1].Value.ToString();
        }

        #region formLoad
        private void OrderSystem_Load(object sender, EventArgs e)
        {
            // TODO: 這行程式碼會將資料載入 'orderingDataSet1.employee' 資料表。您可以視需要進行移動或移除。
            //this.employeeTableAdapter.Fill(this.orderingDataSet1.employee);
            // TODO: 這行程式碼會將資料載入 'orderingDataSet.broil' 資料表。您可以視需要進行移動或移除。
            //this.broilTableAdapter.Fill(this.orderingDataSet.broil);
            formLoad();
        }
        #endregion

        private void dataGridView1_MouseDoubleClick(object sender, MouseEventArgs e)
        {

        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            try
            {
                string RiceNoodles = "";
                string NoodlesItem = "";
                if (groupBox2.Visible == true)
                {
                    if (rdbNoodles.Checked)
                    {
                        RiceNoodles = "麵";
                        dataGridView2.Rows.Add(new Object[] { txbItems.Text,cbxLarge.CheckState,cbxCheese.CheckState,
                RiceNoodles,NoodlesItem,txbPrice.Text,numericUpDown1.Value.ToString(),
                calc(txbPrice.Text,numericUpDown1.Value.ToString()).ToString()});
                        Total();
                        cancel();
                    }
                    else if (rdbRice.Checked)
                    {
                        RiceNoodles = "飯";
                        dataGridView2.Rows.Add(new Object[] { txbItems.Text,cbxLarge.CheckState,cbxCheese.CheckState,
                RiceNoodles,NoodlesItem,txbPrice.Text,numericUpDown1.Value.ToString(),
                calc(txbPrice.Text,numericUpDown1.Value.ToString()).ToString()});
                        Total();
                        cancel();
                    }
                    else { MessageBox.Show("沒有選麵或飯!!!", "警告", MessageBoxButtons.OK, MessageBoxIcon.Warning); }
                }
                else if (groupBox1.Visible == true)
                {
                    if (rdbSquid.Checked) NoodlesItem = "墨魚麵";
                    else if (rdbPenne.Checked) NoodlesItem = "斜管麵";
                    dataGridView2.Rows.Add(new Object[] { txbItems.Text,cbxLarge.CheckState,cbxCheese.CheckState,
                RiceNoodles,NoodlesItem,txbPrice.Text,numericUpDown1.Value.ToString(),
                calc(txbPrice.Text,numericUpDown1.Value.ToString()).ToString()});
                    Total();
                    cancel();
                }
            }
            catch (Exception ee) { MessageBox.Show("錯誤", ee.Message); }
        }

        private void Total()
        {
            int total = 0;
            for (int i = 0; i < dataGridView2.Rows.Count; i++)
            {
                DataGridViewRow row = dataGridView2.Rows[i];
                if (row.Cells[0].Value != null)
                    total += int.Parse(row.Cells[7].Value.ToString());
            }
            tbxTotal.Text = total.ToString();
        }

        #region calc
        private int calc(string price, string quantity)
        {
            int qq = int.Parse(price) * int.Parse(quantity);
            return qq;
        }
        #endregion 

        #region cbxCheese_CheckedChanged
        private void cbxCheese_CheckedChanged(object sender, EventArgs e)
        {
            if (txbPrice.Text == "") { return; }
            a = int.Parse(txbPrice.Text);
            if (cbxCheese.Checked)
            { txbPrice.Text = (a + 10).ToString(); }
            else { txbPrice.Text = (a - 10).ToString(); }
        }
        #endregion

        #region cbxLarge_CheckedChanged
        private void cbxLarge_CheckedChanged(object sender, EventArgs e)
        {
            if (txbPrice.Text == "") { return; }
            a = int.Parse(txbPrice.Text);
            if (cbxLarge.Checked)
            { txbPrice.Text = (a + 10).ToString(); }
            else { txbPrice.Text = (a - 10).ToString(); }
        }
        #endregion

        private void btnDelete_Click(object sender, EventArgs e) { cancel(); }

        private void rdbSquid_CheckedChanged(object sender, EventArgs e)
        {
            if (txbPrice.Text == "") { return; }
            a = int.Parse(txbPrice.Text);
            if (rdbSquid.Checked)
            { txbPrice.Text = (a + 20).ToString(); }
            else { txbPrice.Text = (a - 20).ToString(); }
        }

        private void rdbPenne_CheckedChanged(object sender, EventArgs e)
        {
            if (txbPrice.Text == "") { return; }
            a = int.Parse(txbPrice.Text);
            if (rdbPenne.Checked)
            { txbPrice.Text = (a + 10).ToString(); }
            else { txbPrice.Text = (a - 10).ToString(); }
        }

        private void dataGridView2_ColumnDisplayIndexChanged(object sender, DataGridViewColumnEventArgs e)
        {

        }

        private void dataGridView1_BindingContextChanged(object sender, EventArgs e)
        {
        }

        private void dataGridView2_RowContextMenuStripChanged(object sender, DataGridViewRowEventArgs e)
        {
        }

        private void dataGridView1_RowContextMenuStripChanged(object sender, DataGridViewRowEventArgs e)
        {
        }

        private void dataGridView1_SelectionChanged(object sender, EventArgs e)
        {
            cancel();
        }

        #region cancel()
        private void cancel()
        {
            txbItems.Text = ""; txbPrice.Text = ""; numericUpDown1.Value = 1;
            cbxCheese.Checked = false; cbxLarge.Checked = false;
            rdbNoodles.Checked = false; rdbPenne.Checked = false;
            rdbRice.Checked = false; rdbSquid.Checked = false;
            txbPrice.Text = "";
        }
        #endregion
    }
}
