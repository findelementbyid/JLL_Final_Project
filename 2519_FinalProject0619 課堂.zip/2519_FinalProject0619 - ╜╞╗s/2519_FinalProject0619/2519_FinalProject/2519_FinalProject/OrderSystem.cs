﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace _2519_FinalProject
{
    public partial class OrderSystem : Form
    {
        static int price = 0;
        int a;
        static string num = "";
        Random RR = new Random();


        public OrderSystem()
        {
            InitializeComponent();
            this.ControlBox = false;
        }

        #region btnExit
        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Hide();
        }
        #endregion

        #region formLoad 方法
        private void formLoad()
        {
            SqlConnectionStringBuilder sqlConnStrBuilder = new SqlConnectionStringBuilder("server=usingnamespace.ddns.net;database=ordering;uid=wei;pwd=1212");
            SqlConnection sqlConn = new SqlConnection(sqlConnStrBuilder.ConnectionString);
            sqlConn.Open();
            int[] qq = new int[orderingDataSet2.Tables[3].Rows.Count];
            for (int i = 0; i < orderingDataSet.Tables.Count; i++)
            {
                if (orderingDataSet.Tables[i].ToString() == "employee") { continue; }

                check.menu.Add(orderingDataSet.Tables[i].ToString());
            }
            foreach (string menuTable in check.menu) { cbxMenu.Items.Add(menuTable); }
            DBselect();
            sqlConn.Close();
        }
        #endregion

        #region check_items
        private void checkitems(string state)
        {
            if (state == "soup")
            { groupBox1.Visible = false; groupBox2.Visible = false; cbxCheese.Visible = false; cbxLarge.Visible = false; }
            else if (state == "rice")
            { groupBox1.Visible = false; groupBox2.Visible = false; cbxCheese.Visible = true; cbxLarge.Visible = true; }
            else if (state == "broil")
            { groupBox1.Visible = false; groupBox2.Visible = true; }
            else
            { groupBox1.Visible = true; groupBox2.Visible = false; cbxCheese.Visible = true; cbxLarge.Visible = true; }
        }
        #endregion 

        #region connect to DB
        private void accessDB(string element)
        {
            SqlConnectionStringBuilder sqlConnStrBuilder = new SqlConnectionStringBuilder("server=usingnamespace.ddns.net;database=ordering;uid=wei;pwd=1212");
            SqlConnection sqlConn = new SqlConnection(sqlConnStrBuilder.ConnectionString);
            sqlConn.Open();
            SqlDataAdapter sqlda = new SqlDataAdapter("SELECT * FROM " + element, sqlConn);
            DataSet ds = new DataSet("ds_" + element);
            sqlda.Fill(ds, "ds_" + element);
            bindingSource1.DataSource = ds.Tables[0];
            bindingNavigator1.BindingSource = bindingSource1;
            dataGridView1.DataSource = bindingSource1;
            dataGridView1.AutoResizeRows();
            dataGridView1.AutoResizeColumns();
            bindingNavigator1.BindingSource = bindingSource1;
            sqlConn.Close();
        }
        #endregion

        #region cbxMenu_SelectedIndexChanged
        private void cbxMenu_SelectedIndexChanged_1(object sender, EventArgs e)
        {
            cancel();
            if (cbxMenu.SelectedIndex == 0) { checkitems("broil"); accessDB("broil"); }
            else if (cbxMenu.SelectedIndex == 1) { checkitems("noodles"); accessDB("noodles"); }
            else if (cbxMenu.SelectedIndex == 2) { checkitems("pasta"); accessDB("pasta"); }
            else if (cbxMenu.SelectedIndex == 3) { checkitems("rice"); accessDB("rice"); }
            else if (cbxMenu.SelectedIndex == 4) { checkitems("soup"); accessDB("soup"); }
        }
        #endregion

        #region dataGridView1_CellContentClick
        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (dataGridView1.Rows[e.RowIndex].Cells[0].Value == null) return;
            txbItems.Text = dataGridView1.Rows[e.RowIndex].Cells[0].Value.ToString();
            txbPrice.Text = dataGridView1.Rows[e.RowIndex].Cells[1].Value.ToString();
        }
        #endregion

        #region OrderNum 方法
        private void OrderNum()
        {
            num = RR.Next(11111, 99999).ToString();
            int[] rr = new int[dataGridView3.Rows.Count];
            for (int i = 0; i < dataGridView3.Rows.Count - 1; i++)
            {
                rr[i] = int.Parse(dataGridView3.Rows[i].Cells[1].Value.ToString());
                if (num == rr[i].ToString()) { num = RR.Next(11111, 99999).ToString(); }
            }
            label5.Text = "User : " + check.user;
            textBox1.Text = num;
        }
        #endregion

        #region formLoad 
        private void OrderSystem_Load(object sender, EventArgs e)
        {
            // TODO: 這行程式碼會將資料載入 'orderingDataSet6.transaction1' 資料表。您可以視需要進行移動或移除。
            this.transaction1TableAdapter1.Fill(this.orderingDataSet6.transaction1);
            num = RR.Next(11111, 99999).ToString();
            OrderNum();
            formLoad();
        }
        #endregion

        #region btnAdd()
        private void btnAdd_Click(object sender, EventArgs e)
        {
            try
            {
                string RiceNoodles = "";
                string NoodlesItem = "";
                if (rdbNoodles.Checked) RiceNoodles = "麵";
                else if (rdbRice.Checked) RiceNoodles = "飯";
                if (rdbSquid.Checked) NoodlesItem = "墨魚麵";
                else if (rdbPenne.Checked) NoodlesItem = "斜管麵";
                if (groupBox2.Visible)
                {
                    if (rdbNoodles.Checked == false && rdbRice.Checked == false)
                    {
                        MessageBox.Show("請選擇飯或麵類", "Error!", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        return;
                    }
                }
                dataGridView2.Rows.Add(new Object[] { txbItems.Text,cbxMenu.Text,cbxLarge.CheckState,cbxCheese.CheckState,
                RiceNoodles,NoodlesItem,txbPrice.Text,numericUpDown1.Value.ToString(),
                calc(txbPrice.Text,numericUpDown1.Value.ToString()).ToString()});
                dataGridView2.AutoResizeColumns();
                Total();
                cancel();
            }
            catch (Exception ee)
            {
                MessageBox.Show(ee.ToString(), "Error!",
MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        #endregion

        #region Total方法
        private void Total()
        {
            int total = 0;
            for (int i = 0; i < dataGridView2.Rows.Count; i++)
            {
                DataGridViewRow row = dataGridView2.Rows[i];
                if (row.Cells[0].Value != null)
                    total += int.Parse(row.Cells[8].Value.ToString());
            }
            tbxTotal.Text = total.ToString();
        }
        #endregion

        #region calc 方法
        private int calc(string price, string quantity)
        {
            int qq = int.Parse(price) * int.Parse(quantity);
            return qq;
        }
        #endregion 

        #region CheckBox Change
        private void cbxCheese_CheckedChanged(object sender, EventArgs e)
        {
            if (txbPrice.Text == "") { return; }
            a = int.Parse(txbPrice.Text);
            if (cbxCheese.Checked)
            { txbPrice.Text = (a + 10).ToString(); }
            else { txbPrice.Text = (a - 10).ToString(); }
        }
        
        private void cbxLarge_CheckedChanged(object sender, EventArgs e)
        {
            if (txbPrice.Text == "") { return; }
            a = int.Parse(txbPrice.Text);
            if (cbxLarge.Checked)
            { txbPrice.Text = (a + 10).ToString(); }
            else { txbPrice.Text = (a - 10).ToString(); }
        }
        #endregion

        # region btnDelete_Click
        private void btnDelete_Click(object sender, EventArgs e) { cancel(); }
        #endregion

        #region RadioBtn Change
        private void rdbSquid_CheckedChanged(object sender, EventArgs e)
        {
            if (txbPrice.Text == "") { return; }
            a = int.Parse(txbPrice.Text);
            if (rdbSquid.Checked)
            { txbPrice.Text = (a + 20).ToString(); }
            else { txbPrice.Text = (a - 20).ToString(); }
        }

        private void rdbPenne_CheckedChanged(object sender, EventArgs e)
        {
            if (txbPrice.Text == "") { return; }
            a = int.Parse(txbPrice.Text);
            if (rdbPenne.Checked)
            { txbPrice.Text = (a + 10).ToString(); }
            else { txbPrice.Text = (a - 10).ToString(); }
        }
        #endregion

        #region dataGridView1_SelectionChanged
        private void dataGridView1_SelectionChanged(object sender, EventArgs e)
        {
            cancel();
        }
        #endregion

        #region Check out
        private void btnCheckout_Click(object sender, EventArgs e)
        {
            string cell1 = "", cell2 = "";
            //string orderNum = RR.Next(11111, 99999).ToString();
            DialogResult result = MessageBox.Show("確定點餐嗎?", "注意", MessageBoxButtons.OKCancel, MessageBoxIcon.Information);
            if (result == DialogResult.OK)
            {
                SqlConnection conn = new SqlConnection(@"server=usingnamespace.ddns.net;database=ordering;uid=wei;pwd=1212");
                SqlDataAdapter da = new SqlDataAdapter();
                conn.Open();

                for (int i = 0; i < dataGridView2.Rows.Count - 1; i++)
                {
                    SqlCommand cmd = new SqlCommand("insert into [transaction1](date,OrderNum,category,items,large,cheese,RiceNoodles,CuttlePenne,price,quantity,total)"
                         + "values (@date,@OrderNum,@category,@items,@large,@cheese,@RiceNoodles,@CuttlePenne,@price,@quantity,@total)", conn);
                    cell1 = dataGridView2.Rows[i].Cells[2].Value.ToString();
                    cell2 = dataGridView2.Rows[i].Cells[3].Value.ToString();
                    if (cell1 == "Unchecked") { cell1 = "否"; }
                    else if (cell1 == "Checked") { cell1 = "是"; }
                    if (cell2 == "Unchecked") { cell2 = "否"; }
                    else if (cell2 == "Checked") { cell2 = "是"; }
                    cmd.Parameters.Add("@date", SqlDbType.NChar).Value = DateTime.Now.ToString();
                    cmd.Parameters.Add("@OrderNum", SqlDbType.NChar).Value = textBox1.Text;
                    cmd.Parameters.Add("@category", SqlDbType.NChar).Value = dataGridView2.Rows[i].Cells[1].Value;
                    cmd.Parameters.Add("@items", SqlDbType.NChar).Value = dataGridView2.Rows[i].Cells[0].Value;
                    cmd.Parameters.Add("@large", SqlDbType.NChar).Value = cell1;
                    cmd.Parameters.Add("@cheese", SqlDbType.NChar).Value = cell2;
                    cmd.Parameters.Add("@RiceNoodles", SqlDbType.NChar).Value = dataGridView2.Rows[i].Cells[4].Value;
                    cmd.Parameters.Add("@CuttlePenne", SqlDbType.NChar).Value = dataGridView2.Rows[i].Cells[5].Value;
                    cmd.Parameters.Add("@price", SqlDbType.NChar).Value = dataGridView2.Rows[i].Cells[6].Value;
                    cmd.Parameters.Add("@quantity", SqlDbType.NChar).Value = dataGridView2.Rows[i].Cells[7].Value;
                    cmd.Parameters.Add("@total", SqlDbType.NChar).Value = dataGridView2.Rows[i].Cells[8].Value;

                    cmd.ExecuteNonQuery();
                }
                int[] rr = new int[dataGridView3.Rows.Count];
                for (int i = 0; i < dataGridView3.Rows.Count - 1; i++)
                {
                    rr[i] = int.Parse(dataGridView3.Rows[i].Cells[1].Value.ToString());
                    if (textBox1.Text == rr[i].ToString()) { textBox1.Text = RR.Next(11111, 99999).ToString(); }
                }
                OrderNum();
                MessageBox.Show("點餐成功");
            }
            else return;
            tbxTotal.Text = "";
            DBselect();
            dataGridView2.Rows.Clear();
        }
        #endregion

        #region cancel()
        private void cancel()
        {
            txbItems.Text = ""; txbPrice.Text = ""; numericUpDown1.Value = 1;
            cbxCheese.Checked = false; cbxLarge.Checked = false;
            rdbNoodles.Checked = false; rdbPenne.Checked = false;
            rdbRice.Checked = false; rdbSquid.Checked = false;
            txbPrice.Text = "";
        }
        #endregion

        #region btnDrop_Click
        private void btnDrop_Click(object sender, EventArgs e)
        {
            foreach (DataGridViewRow row in dataGridView2.SelectedRows)
            { dataGridView2.Rows.Remove(row); }
            Total();
        }
        #endregion

        #region DBselect 方法
        private void DBselect()
        {
            SqlConnectionStringBuilder sqlConnStrBuilder = new SqlConnectionStringBuilder("server=usingnamespace.ddns.net;database=ordering;uid=wei;pwd=1212");
            SqlConnection sqlConn = new SqlConnection(sqlConnStrBuilder.ConnectionString);
            sqlConn.Open();
            SqlDataAdapter sqlda = new SqlDataAdapter("SELECT * FROM [transaction1]", sqlConn);
            DataSet ds = new DataSet("ds_transaction1");
            sqlda.Fill(ds, "ds_transaction1");
            orderBindingSource8.DataSource = ds.Tables[0];
            bindingNavigator1.BindingSource = orderBindingSource8;
            dataGridView3.DataSource = orderBindingSource8;
            dataGridView3.AutoResizeRows();
            dataGridView3.AutoResizeColumns();
            bindingNavigator1.BindingSource = orderBindingSource8;
            sqlConn.Close();
        }
        #endregion

        private void bindingNavigator1_RefreshItems(object sender, EventArgs e)
        {

        }
    }
}
